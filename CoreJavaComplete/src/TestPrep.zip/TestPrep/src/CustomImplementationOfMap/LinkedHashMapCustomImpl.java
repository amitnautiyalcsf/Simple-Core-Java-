package CustomImplementationOfMap;

class LinkedHashingMap<K,V>{

	private Entry<K,V>[] table;
	private int capacity;
	private Entry<K,V> Header ;
	private Entry<K,V> last;
	
	static class Entry<K,V>
	{
		K key;
		V value;
		Entry<K,V> next;
		Entry<K,V> after, before;
		
		public Entry( K key, V value, Entry<K,V> next) {
			
			this.key = key;
			this.value=value;
			this.next=next;
		}
	}
	
	@SuppressWarnings("unchecked")
	public LinkedHashingMap() {
		// TODO Auto-generated constructor stub
		table = new Entry[capacity];
	}
	
	public void put(K newkey, V data)
	{
	
		if(newkey== null)
		{
			return;
		}
		
		int hash = hash(newkey);
		
		
		
	}
	
	 private int hash(K key){
	        return Math.abs(key.hashCode()) % capacity;
	    }
	
	
}
public class LinkedHashMapCustomImpl
{
	

}

