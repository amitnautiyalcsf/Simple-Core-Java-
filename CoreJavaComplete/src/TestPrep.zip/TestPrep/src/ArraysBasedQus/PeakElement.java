package ArraysBasedQus;

import java.util.Arrays;

public class PeakElement {

	
	public static void main(String[] args) {
		int arr[] = {6,1,15, 19, 9, 13, 12, 6, 7, 2, 10, 4,1,14,11,14,14,13};
		
		Arrays.sort(arr);
		
		System.out.println(arr[arr.length-1]);
	}
}
