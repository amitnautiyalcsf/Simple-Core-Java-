package ArraysBasedQus;

public class SmallestPositiveIntegerValueThatCannotbeRepresentedAsSumOfAnySubsetOfAGivenArray {

	  public static void main(String[] args) {
		int arr3[] = {1, 3, 6, 10, 11, 15};
		int arr[]= {1, 1, 3, 4};
		int arr1[]=  {1, 2, 5, 10, 20, 40};
		int arr2[]= {1, 2, 3, 4, 5, 6};
		
		int count = 1;
		
		for(int i =0; i< arr2.length;i++)
		{
			
			if(arr2[i]>count)
			{
				System.out.println(count);
				System.exit(0);
			}
			else {
				
				count = count+ arr2[i];
				
			}
			
		}
		
		System.out.println(count);
		
		
		
		
		  
		  
		  
		  
	}
	}
	

