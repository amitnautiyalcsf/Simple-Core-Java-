package ArraysBasedQus;

import java.util.HashSet;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class subarraysWithGivenSumInNSquareApproach {
public static void main(String[] args) {
	int arr[] = { 3, 4, -7, 1, 3, 3, 1, -4 };
	int sum = 7;
	
	for(int i =0;i <arr.length;i++)
	{
		int curr_sum=0;

		for(int j = i; j<arr.length;j++)
		{
		
			curr_sum = curr_sum + arr[j];
			if(curr_sum == sum)
			{
				print(arr,i, j);
			}
		
		}
		}
		
    }

public static void print(int[] nums, int i, int j)
{
    System.out.println(IntStream.range(i, j + 1)
                                .mapToObj(k -> nums[k])
                                .collect(Collectors.toList()));
    
}


}
