package ArraysBasedQus;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class RGBArrayQus {
public static void main(String[] args) throws IOException {
	{	
	String str= "";
		
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
	{
			str = str + br;
	}
		
		int arr[]= new int[3];
		
		for(int i =0; i <str.length(); i ++)
		{

			
		


		}
}
}
