package LRUCache;

import java.util.*;

class LRUCacheImplementation {
 
	

	
	
    Set<Integer> cache;
    int capacity;
 
    public LRUCacheImplementation(int capacity)
    {
        this.cache = new LinkedHashSet<Integer>(capacity);
        this.capacity = capacity;
    }
 
    public boolean get(int key)
    {
        if (!cache.contains(key))
            return false;
        cache.remove(key);
        cache.add(key);
        return true;
    }
 
    /* Refers key x with in the LRU cache */
    public void refer(int key)
    {       
        if (get(key) == false)
           put(key);
    }
 
    // displays contents of cache in Reverse Order
    public void display()
    {
      LinkedList<Integer> list = new LinkedList<>(cache);
      Iterator<Integer> itr = list.descendingIterator();
       
      while (itr.hasNext())
            System.out.print(itr.next() + " ");
    }
     
    public void put(int key)
    {
         
      if (cache.size() == capacity) {
            int firstKey = cache.iterator().next();
            cache.remove(firstKey);
        }
 
        cache.add(key);
    }
    
    
     
    public static void main(String[] args)
    {
    	LRUCacheImplementation ca = new LRUCacheImplementation(4);
        ca.refer(1);
        ca.refer(2);
        ca.refer(3);
        ca.refer(1);
        ca.refer(4);
        ca.refer(5);
        ca.display();
    }
   
}


// workingInput 4 
//3 2 1
//1 3 2
//4 1 3 2
//5 4 1 3 



// arr[5,1,0,4,6]

    *
*   *
*  **
*  **
*  **
** ** 
*****


//rowCount  = 4 
//columncount = 4

// 1  2   3   4
// 4  5   6   8
// 9  10  11  12
// 13 14  15  16


//1 2 3 4 8 12 16 15 14 13 9 4 5 6 11 10



