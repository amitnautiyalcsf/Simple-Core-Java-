
public class LargestSumofContigousArrayKedansAlgo {

	public static void kadanesAlgo(int arr[])
	{
		
		int sum = Integer.MIN_VALUE;
		int start =0;
		int end=0;
		int s=0;
		int curr_sum= 0;
		for(int i=0;i<arr.length;i++)
		{
			
		    curr_sum = curr_sum + arr[i];
			
		    if(curr_sum>sum)
		    {
		    	sum = curr_sum;
		    	start =s;
		    	end=i;
		    }
		    
		    if(curr_sum<0)
		    {
		    	curr_sum=0;
		    	s= i+1;
		    	
		    }
			
		}
		
		System.out.println(sum);
		System.out.println(s);
		System.out.println(end);
		
	}
	
	public static void main(String[] args) {
		int arr[] = {-2, -3, 4, -1, -2, 1, 5, -3};
		kadanesAlgo(arr);
		
	}
}
