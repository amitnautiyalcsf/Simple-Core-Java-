package volatilePackage;

public class VolatileEx {
	static  volatile int i =10;
public static void main(String[] args) {
	
//	Runnable r =()->{
//		
//		i = i+1;
//		System.out.println(i + Thread.currentThread().getName());
//		
//		
//	}; 
	
	Thread t1 = new Thread(()->{
		
		
		System.out.println(i + Thread.currentThread().getName());
	},"t1 thread");
	
	
Thread t2 = new Thread(()->{
	    i = i+1;
		System.out.println(i + Thread.currentThread().getName());
	},"t2 thread");
	

//	r.run();
	t1.start();
	t2.start();

	System.out.println(i);
	
}
}
