package GenericsInJava;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

class Ammy<T1,T2>
{

	T1 obj1;
	T2 obj2;
	
	public Ammy(T1 obj1, T2 obj2) {

		this.obj1= obj1;
		this.obj2 =obj2;
	}
	
	
	public int show()
	{
		String data1 = obj1.toString();
		String data2 = obj2.toString();
		
		int data3 = Integer.parseInt(data1);
		int data4 = Integer.parseInt(data2);
		System.out.println(data3+data4);
		
		return (data3+data4);
		
		
	}
	

	
}


public class AddTwoNosUsingGenerics {

	public static void main(String[] args) {
		Ammy obj6 = new Ammy(4, 6);
		obj6.show();
		
		List<Integer>al = Arrays.asList(4,6,1,2,7,8,3,8,3,1,9);
		Set<Integer>s1 = new HashSet<Integer>();
		for(int x: al)
		{
			s1.add(x);
			
		}
		
		List<Integer>al2 = Arrays.asList(45,21,5,10,9,5,3,6,3,1,10,41);
		Set<Integer>s2 = new HashSet<Integer>();
		for(int x: al)
		{
			s2.add(x);
			
		}
		
		Set<Integer>s3 = new TreeSet<Integer>();
		
		for(int x: s1)
		{
			s3.add(x);
			
		}
		
		for(int x: s2)
		{
			s3.add(x);
		}
		
		for(int x:s3)
		{
			
			System.out.println(x);
		}
		
		
	}
	
}
