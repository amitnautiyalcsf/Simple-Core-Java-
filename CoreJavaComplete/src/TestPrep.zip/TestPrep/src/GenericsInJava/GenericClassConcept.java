package GenericsInJava;

class Check <T> {
	
	T obj;
	
	public Check(T obj) {
		
		this.obj= obj;
		
		System.out.println(obj);
	}


}

public class GenericClassConcept
{
	public static void main(String[] args) {
		Check<Integer> obj1 = new Check<Integer>(3);
		
		Check<String> obj2 = new Check<String>("Amit");
		

	}
	
}