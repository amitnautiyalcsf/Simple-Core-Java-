package GenericsInJava;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AdvantageOfGenerics {
public static void main(String[] args) {
		List al = new ArrayList<>();
	
		al.add(12);
		al.add(15);
		al.add("Amit");
		
		Iterator itr = al.iterator();
		while(itr.hasNext())
		{
			
			System.out.println(itr.next());
		}
		
}	
	
	
}
