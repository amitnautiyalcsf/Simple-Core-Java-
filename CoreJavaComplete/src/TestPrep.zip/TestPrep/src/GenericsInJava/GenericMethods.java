package GenericsInJava;

class Ab
{

	public static <T> void show(T data)
	{
		System.out.println(data);
	}

		
}




public class GenericMethods {

	public static void main(String[] args) {
		 Ab.show(2);
		 Ab.show("Amit");
		
	}
	
}
