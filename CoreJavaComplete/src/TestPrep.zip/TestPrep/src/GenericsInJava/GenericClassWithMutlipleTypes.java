package GenericsInJava;

class Mo<T1,T2>
{
	
	T1 obj1;
	T2 obj2;
	
	public Mo(T1 obj1, T2 obj2) {
		
		this.obj1= obj1;
		this.obj2 = obj2;
		
		
	}
	
	public void show()
	{
		System.out.println(obj1);
		System.out.println(obj2);
		
	}
	
	
}


public class GenericClassWithMutlipleTypes {

	public static void main(String[] args) {
		
		Mo obj3 = new Mo(2,"Amit");
		Mo obj4 = new Mo(3, "Rohit");
		
		
		obj3.show();
		obj4.show();
		
		
		
		
	}
}
