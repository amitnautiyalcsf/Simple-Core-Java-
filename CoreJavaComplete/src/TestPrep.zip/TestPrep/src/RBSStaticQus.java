import java.util.ArrayList;
import java.util.List;

public class RBSStaticQus {
	
	static void print(List<Integer> x)
	{
		x.add(30);
		System.out.println("Test");
		
		
	}
	
	
public static void main(String[] args) {

	int x = 10;
	List<Integer> l1 = new ArrayList<Integer>();
	print(l1);
	System.out.println(x);
	System.out.println(l1);
	
	
	
}
}
