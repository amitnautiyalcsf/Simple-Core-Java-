package coreJavaConcepts;

interface Aty{
	
  public void show();
  public void display();
}


public class Anonymous {
public static void main(String[] args) {
	
	Aty obj = new Aty() {
		
		public void show(){
		
			System.out.println("This is show Mthod");
		}
		
		public void display() {
			System.out.println("This is disp method");
		}
	};
	
	obj.show();
	obj.display();
	
}
	
}
