package coreJavaConcepts;

class Pop
{
	
	Pop()
	{
	
		System.out.println("ParentCons");
		
	}
	public void show()
	{
		System.out.println("Show method");
		
	}
	
	public void disp()
	{
		System.out.println("Display Method");
	}
	

}

class Qwe extends Pop{
	
	Qwe()
	{
		System.out.println("ChildCons");
		
	}
	public void show()
	{
		super.show();
		System.out.println("This is Qwe class Show method");
	}
	
	public void temp()
	{
		System.out.println("This is temp method");
		
	}
	
}



public class DynamicMethodDispatch
{
	public static void main(String[] args) {
		
		Pop obj = new Qwe(); // Dynamica method dispatch.
		obj.show();
		obj.disp();
	//	obj.temp();  bcoz this method is not in Pop class
		
		
	}
}



















//class A1{
//	
//	public void show()
//	{
//		System.out.println("It is A's show method");
//	}
//	
//}
//
//class B1 extends A1
//{
//	
//public void show()
//{
//System.out.println("It is B's show method");	
//}
//
//public void config()
//{
//	System.out.println("It is config method of B");
//	}
//	
//}
//
//class C1 extends A1
//{
//public void show()
//{
//
//	System.out.println("It is a C's show method ");
//}
//}
//public class DynamicMethodDispatch {
//	
//	public static void main(String[] args) {
//
//		A1 obj = new B1();
//		obj.show(); // B's show is called bcoz we have created an object of B while creating an instance of A
//		            //also show is overriden in B  
//		
//		
////		obj.config(); // error Bcoz we have a reference of A and in A we don;t have config method
//		
//		A1 obj2 = new C1();
//		obj2 .show();
//				
//		
//	}
//}


