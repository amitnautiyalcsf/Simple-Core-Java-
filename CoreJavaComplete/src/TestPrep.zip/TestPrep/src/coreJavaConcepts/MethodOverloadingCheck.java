package coreJavaConcepts;

public class MethodOverloadingCheck {

	public final int disp(int data)
	{
		System.out.println(data);
		
		try {
			
			// System.exit(0);
			 
			 return data;
		}
		catch(Exception e)
		{
			
		}
		
		finally {
			System.out.println("Finally executes");
		}
		
		return 1;
	}
	
	public void disp(String data)
	{
		
		System.out.println(data);
	}
	
	public static void main(String[] args) {
		MethodOverloadingCheck obj = new MethodOverloadingCheck();
		obj.disp(10);
		obj.disp("20");
		
	}
	
}
