package Test;

interface AB
{

	int i = 10;
	
	default void disp()
	{
		System.out.println("Disp Method");
		
	}
	
}


public class IntefcaeVariable implements AB {
	
	public static void main(String[] args) {
		AB obj = new IntefcaeVariable();
		System.out.println(obj.i);
		
		System.out.println(AB.i);
		
		obj.disp();
	}

}
