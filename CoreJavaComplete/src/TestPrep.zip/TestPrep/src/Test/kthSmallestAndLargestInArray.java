package Test;

import java.util.Map;
import java.util.TreeMap;

public class kthSmallestAndLargestInArray {
	
	public static int kthSmallest(Map<Integer,Integer>m1, int k)
	{
		
		int count =0;
		for(Map.Entry<Integer, Integer>m2: m1.entrySet())
		{
			count = count + m2.getValue();
			
			if(count>=k)
			{
				return m2.getKey();
			}
			
		}
		return -1;
	
		
		
	}
	
public static void main(String[] args) {
	int arr[]= {12,5,1,19,8,20};
	int k =3;
	Map<Integer, Integer> m1 = new TreeMap<>();
	
	for(int i =0;i<arr.length;i++)
	{
		m1.put(arr[i], m1.getOrDefault(arr[i], 0) +1);
	}
	
	int ans =kthSmallest(m1,k);
	
	System.out.println(ans);
	
	
}
}
