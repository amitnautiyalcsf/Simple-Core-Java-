package Test;

import java.util.*;

class TCSTest
{

    static void findXorSum(int arr[], int n)
    {

        int xor_sum = 0;
        int multi = 1;
     
        for (int i = 0; i < 30; i++)
        {

            int cnt_odd = 0;
     
     
            boolean flag = false;
     
            for (int j = 0; j < n; j++)
            {
                if ((arr[j] & (1 << i)) > 0)
                    flag = (!flag);
                if (flag)
                    cnt_odd++;
            }
     
            for (int j = 0; j < n; j++)
            {
                xor_sum += (multi * cnt_odd);
     
                if ((arr[j] & (1 << i)) > 0)
                    cnt_odd = (n - j - cnt_odd);
            }
     
            
            multi *= 2;
        }
     
        System.out.println(xor_sum);
    }
 
    
    public static void main(String[] args)
    {
        int arr[] = { 5, 1, 3, 2,5,4 };
        int n = arr.length;
 
      findXorSum(arr, n);
    }
}
