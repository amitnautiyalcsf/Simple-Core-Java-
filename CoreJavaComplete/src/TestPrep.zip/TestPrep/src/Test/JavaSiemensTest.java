package Test;

public class JavaSiemensTest {
	static int s =0;
public static void main(String[] args) {
		
		m1();
		System.out.println(s);
		
		
	}
	
	
	public static void m1()
	{
		int x =1;
		m2(x);
		System.out.println(x);
		
		
	}
	
	public static void m2(int x)
	{
		x = x*2;
		s=x;
	}

}
