package Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Movie implements Comparable<Movie>
{
	private double rating;
	private String name;
	private int year;
	
	public Movie( double rating, String name, int year) {
		this.rating= rating;
		this.name = name;
		this.year= year;
		
	}
	

	public double getRating() {
		return rating;
	}


	public String getName() {
		return name;
	}


	public int getYear() {
		return year;
	}




	@Override
	public int compareTo(Movie o) {
		return (this.year - o.year);
	}
	
}


public class ComparableAndCompara {

	public static void main(String[] args) {
		Movie m = new Movie(3.5,"LOC",2018);
		Movie m1 = new Movie(4.5,"Gadar", 2009);
		Movie m3 = new Movie(1.3,"MyNameisKhan", 2017);
		
		List<Movie> l1 = new ArrayList<Movie>();
		l1.add(m);
		l1.add(m1);
		l1.add(m3);
		System.out.println("Sorting based on year");
		Collections.sort(l1);
		
		for(Movie x : l1 )
		{
	
			System.out.println(x.getName()+ " " + x.getRating()+ " "+ x.getYear());
			
		}
		
		System.out.println(" ");
		System.out.println("Sorting based on name");
		
		
		Comparator<Movie>c = new Comparator<Movie>() {

			@Override
			public int compare(Movie o1, Movie o2) {
				return o1.getName().compareTo(o2.getName());
			}
		};
		
		
		Collections.sort(l1, c);

		for(Movie x: l1)
		{
			System.out.println(x.getName()+ " " + x.getRating()+ " "+ x.getYear());
		}
		
		
		System.out.println(" ");
		System.out.println("Sorting based on Rating");
		
		Collections.sort(l1, (o1,o2)->o2.getRating()<o1.getRating()?1:-1);
		
		for(Movie x: l1)
		{
			System.out.println(x.getName()+ " " + x.getRating()+ " "+ x.getYear());
		}
	}
	
}
