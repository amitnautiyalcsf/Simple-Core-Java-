package Test;

class Age
{

	private int day;
	private int month;
	private int year;
	public int getDay() {
		return day;
	}
	public int getMonth() {
		return month;
	}
	public int getYear() {
		return year;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	

}


final class Student
{
	
	private final String name;
	private final Age age;
	private final int id;
	
	public Student(String name, int id , Age age) {
		
		this.name= name;
		this.id= id;
		
		Age cloneAge = new Age();
		cloneAge.setDay(age.getDay());
		cloneAge.setMonth(age.getMonth());
		cloneAge.setYear(age.getYear());
		this.age= cloneAge;
	}

	public String getName() {
		return name;
	}

	public Age getAge() {
		Age cloneAge = new Age();
		cloneAge.setDay(this.age.getDay());
		cloneAge.setMonth(this.age.getMonth());
		cloneAge.setYear(this.age.getYear());
		
		return cloneAge;
	}

	public int getId() {
		return id;
	}

}



public class ImmutableClass {

	public static void main(String[] args) {
		
		Age age = new Age();
		
		age.setDay(24);
		age.setMonth(9);
		age.setYear(1994);
		
		Student st = new Student("Rohit", 101, age);
		
		System.out.println("Year of Rohit is : " + st.getAge().getYear());
		
		st.getAge().setYear(1996);
		
		System.out.println("Year of Rohit is : " + st.getAge().getYear());
		
	}
}
