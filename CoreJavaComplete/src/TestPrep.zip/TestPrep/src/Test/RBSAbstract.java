package Test;

abstract class AP
{

	 int i ;
	 int j;
	
	public AP() {
		this.i = 10;
		this.j = 50;
	}
	
	public abstract void disp();
	
	
}




public class RBSAbstract extends AP {
	
	@Override
	public void disp() {
	System.out.println("Disp Method");	
	}

	public static void main(String[] args) {
		AP obj = new RBSAbstract();
		
		obj.disp();
		System.out.println(obj.i);
		System.out.println(obj.j);
		
	
	}
		
	
	
}
