package Test;

public class SimenesTest {

	static int s;
	
	public static void main(String[] args) {
		SimenesTest obj = new SimenesTest();
		obj.m1();
		System.out.println(s);
	}
	
	public void m1()
	{
		
		int x=1;
		m2(x);
		System.out.println(x);
		
	}
	
	public void m2(int x)
	{
		x= x*2;
		s=x;
	}
	
	
}
