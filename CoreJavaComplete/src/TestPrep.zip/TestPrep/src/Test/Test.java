package Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class Test {

//	public static int perfectSubstring(String s, int k) {
//		
//		int count = 0;
//		
//		Map<Character,Integer> m1 = new HashMap<Character, Integer>();
//		
//		for(int i = 0; i <k ;i++)
//		{
//
//			if(m1.containsKey(s.charAt(i)))
//			{
//				m1.put(s.charAt(i), m1.get(s.charAt(i))+1);
//				
//				
//			}
//			else {
//				m1.put(s.charAt(i), 1);
//			}
//		}
//		
//		if(m1.size()==k)
//		{
//			count++;	
//		}
//		
//		for(int i =k; i<s.length(); i++ )
//		{
//			if(m1.containsKey(s.charAt(i)))
//			{
//				m1.put(s.charAt(i), m1.get(s.charAt(i))+1);
//				
//				
//			}
//			else {
//				m1.put(s.charAt(i), 1);
//			}
//			
//			if (m1.containsKey(s.charAt(i - k))) 
//			{
//				
//				m1.put(s.charAt(i - k), m1.get(s.charAt(i - k))-1);
//			}
//
//			if (m1.containsKey(s.charAt(i - k)) && m1.get(s.charAt(i - k)) == 0) 
//			{
//			
//			m1.remove(s.charAt(i - k));
//			}
//
//			if (m1.size() == k) {
//			count++;
//			}
//			
//			
//			
//		}
//		return count;
//		
//	}
	
	
	public static boolean flag(int[] arr, int k) {
		for(int x : arr) {
			if(x != 0 && x != k) 
				return false;
		}
		return true;
	}
	
	public static int perfectSubstring(String s, int k) {
		int count = 0;
		for(int i=0; i<s.length(); i++) {
			int[] arr = new int[26];
			for(int j = i; j<s.length(); j++) {
				if(j > i + (k*10)) 
				{
					break;
				}
				
				char ch = s.charAt(j);
				
				arr[ch-'0']++;
				if(flag(arr, k)) 
					count++;
				
				
			}
		}
		return count;
	}
	
	
	public static void main(String[] args) {
		
		String str = "1020122";
		int k =2;
		System.out.println(perfectSubstring(str,k));
		
		
		
		String s1 = "Amit";    
		String s2 = "Amit";
		
	//	String s2 = "Rohit";
		
		String s3 = new String("Amit");
		//String s3 = new String("Rohit");
		String s4 = new String("Amit");
		
		//String s4 = new String("Amit");
		
		StringBuffer sb =new StringBuffer("Amit");
		
	//	System.out.println(s1==s2); true
	
    //	System.out.println(s1.equals(s2)); // true	
		
	//	System.out.println(s1==s3); false
		
	//	System.out.println(s1.equals(s3)); // true
		
	
		
	//  System.out.println(s3==s4);	// false
		
	//  System.out.println(s3.equals(s4)); // true
		
	//	System.out.println(s3==sb);	 // compilation error type incompatible
		
   //   System.out.println(s1.hashCode()==s2.hashCode()); // true
		
   //   System.out.println(s1.hashCode()== s3.hashCode());	// true
		
   //   System.out.println(s3.hashCode()==s4.hashCode());	// true
		
		
		List<Integer> al = new CopyOnWriteArrayList<Integer>();
		
		al.add(1);
		al.add(3);
		
		for(int x: al)
		{
			System.out.println(x);
			al.add(5);
			
		}
		
		
		System.out.println(" ");
		
		for(int x: al)
		{
			System.out.println(x);
			
		}
		
		
//		List<Integer>list1 = new ArrayList<>();
//		list1.add(23);
//		list1.add(24);
//		list1.add(25);
//		list1.add(26);
//		
//		for(int x: list1)
//		{
//			list1.add(5);
//			
//		}
		
//		Iterator itr = list1.iterator();
//		
//		while(itr.hasNext())
//		{
//
//			System.out.println(itr.next());
//			list1.add(5);
//			
//		}
		
		
//		for(int i=0;i<list1.size();i++) {
//
//		list1.add(5);
//		}
		
		
		
		
	//HashMap<String, String> 
		
		
		

	
		
		
		
	}

	
	}
