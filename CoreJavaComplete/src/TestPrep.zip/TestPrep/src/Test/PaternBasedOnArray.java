package Test;

import java.util.Collections;

public class PaternBasedOnArray {

	public static void main(String[] args) {

	    int[] arr ={ 5, 1, 0, 4, 6};
	    int max = arr[0];
	    for(int i : arr){
	        if( i > max) max = i;
	    }
	    max = max+1;
	    String[][] result = new String[max][arr.length];
	    for(int i = result.length -1; i >=0; i--){
	        for(int j = 0; j < result[0] .length; j++){
	            if(i == result.length-1){
	                result[i][j] = "*";
	            }
	            else if(arr[j] != 0){
	                result[i][j] = "*";
	                arr[j]--;
	            }else if(arr[j] == 0){
	                result[i][j] = " ";
	            }

	        }
	    }

	    for(int i = 0 ; i < result.length; i++){
	        for( int j = 0 ; j < result[0].length; j++){
	            System.out.print(result[i][j]);
	        }
	        System.out.println();
	    }
	}
}
