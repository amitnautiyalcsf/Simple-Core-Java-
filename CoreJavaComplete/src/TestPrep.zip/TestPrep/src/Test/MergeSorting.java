package Test;

public class MergeSorting {
	
	
	public void mergeSort(int arr[], int start, int end)
	{
		if(start<end)
		{
		int mid = (start+end)/2;
		mergeSort(arr, start, mid);
		mergeSort(arr,mid+1, end);
		merge(arr, start,mid, end);
		}
	}
	
	public void merge(int arr[], int start, int mid, int end)
	{
		int temp[]= new int[end-start+1];
		int i = start;
		int k =0;
		int j = mid+1;
		
		while(i<=mid && j<=end)
		{
			
			if(arr[i]<arr[j])
			{
				temp[k]= arr[i];
				
				i++;
			}
			
			else 
			{
				
				temp[k] = arr[j];
				j++;
				
			}
			
			k++;
			
		}
		
		if(i<=mid)
		{
			while(i<=mid)
			{
				temp[k]= arr[i];
				i++;
				k++;
			}
		}
		
		else if(j<=end)
		{
			while(j<=end)
			{
				temp[k]= arr[j];
				j++;
				k++;
			}
		}
		
		for(int s=0; s <temp.length;s++)
		{

			arr[start+ s]= temp[s];
			
		}
}
	
	public static void main(String[] args) {
		int arr[]= {23,4,221,5,634,34,222,2254,69};
		MergeSorting obj = new MergeSorting();
		obj.mergeSort(arr, 0, arr.length-1);
		
		for(int x: arr)
		{
			System.out.println(x);
		}
	}

}
