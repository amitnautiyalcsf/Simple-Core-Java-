package Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Employee {

	private String name;
	private String gender;
	private int id;
	private int salary;
	
	
	
	
	public Employee(String name, String gender, int id, int salary) {
		super();
		this.name = name;
		this.gender = gender;
		this.id = id;
		this.salary = salary;
	}
	
	public String getName() {
		return name;
	}
	public String getGender() {
		return gender;
	}
	public int getId() {
		return id;
	}
	public int getSalary() {
		return salary;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", gender=" + gender + ", id=" + id + ", salary=" + salary + "]";
	}
	
	
	
	
}

public class streamApisTestExample{
	public static void main(String[] args) {
		
	
	Employee obj = new Employee("amit", "male", 101, 1200000);
	Employee obj1 = new Employee("rohit", "male", 102, 1100000);
	Employee obj2 = new Employee("manu", "female", 100, 1400000);
	Employee obj3 = new Employee("sonali", "female", 103, 30000);
	Employee obj4 = new Employee("piyush", "Male", 105, 27000);
	Employee obj5 = new Employee("varun", "Male", 106, 100000);

	List<Employee>values = Arrays.asList(obj,obj1,obj2,obj3,obj4,obj5);
	
	
//	System.out.println(values.stream().filter(i->i>40000).filter(i->));
	
//	
//	Predicate<Employee> p1 = new Predicate<Employee>() {
//		
//		@Override
//		public boolean test(Employee t) {
//			// TODO Auto-generated method stub
//			return (t.getSalary()>40000);
//		}
//	}; 
//	
//Predicate<Employee> p2 = new Predicate<Employee>() {
//		
//		@Override
//		public boolean test(Employee t) {
//			// TODO Auto-generated method stub
//			return (t.getGender().equalsIgnoreCase("male"));
//		}
//	}; 
	

//Stream s1 = values.stream();
//Stream s2 = s1.filter(p1);
//Stream s3 = s2.filter(p2);


//s3.forEach(Employee-> System.out.println(Employee.toString()));

//List<Employee> l1 = (List<Employee>) s3.collect(Collectors.toList());
//
//for(Employee x: l1)
//{
//System.out.println(x.toString());	
//}
//
//System.out.println(" ");

values.stream().filter(i->i.getSalary()>40000)
.filter(i->i.getGender().equalsIgnoreCase("male"))
.forEach(i -> System.out.println(i));



values.stream().filter(i->i.getSalary()>40000 && i.getGender().equalsIgnoreCase("male"))
.map(i->i.getName())
.forEach(i->System.out.println(i));

//values.stream().filter(i->i.getSalary()>40000)
//.filter(i->i.getGender().equalsIgnoreCase("male"))
//.collect(Collectors.toList());

	
}
}
