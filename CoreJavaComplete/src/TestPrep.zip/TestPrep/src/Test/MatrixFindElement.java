package Test;

public class MatrixFindElement {
public static void main(String[] args) {
	int arr[][]= { { 0, 6, 8, 9 },
                   { 20, 22, 28, 29 },
                   { 36, 38, 50, 61 },
                   { 64, 66, 100, 122 } };
	
	int k = 64;
	
	int i = 0;
	int m = arr[0].length;
	int n =arr.length;
	int j = m-1;
	
	//int s1 = arr[1][3];
	
	while(j>0 && i <n)
	{
		int s = arr[i][j];
		
		if(k>arr[i][j])
		{

			i++;
		}
		else {

			j--;	
		}
		if(arr[i][j]==k)
		{
		
			System.out.println(i+ " " +j);
		}
		
		
		
	}
	
	
	
}
}
