package Test;

public class MissingElementInAnArray {
	
	
	public static void findMissing(int arr[], int n)
	{
		int[] b = new int[arr[n -1]+1];
		
		for(int i =0; i <arr.length; i++ )
		{
			b[arr[i]]= 1;
		}
		
		for(int i =arr[0]; i <b.length;i++)
		{
			if(b[i]==1)
			{
				continue;
			}
			else
			{
				System.out.println(i);
			}
			
		}
		
	}

	public static void main(String[] args) {
		int arr[] = {1,3,5,6,8,10,14};
		int n = arr.length;
		findMissing(arr, n);
	}
}
