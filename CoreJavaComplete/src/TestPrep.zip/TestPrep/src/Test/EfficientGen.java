package Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EfficientGen {

	static int efficientJanitor(List<Float> weight) {
		
		Collections.sort(weight);

		int i = 0;
		int j = weight.size() - 1;
		int count = 0;
		while (i <= j) {
			if (weight.get(i) + weight.get(j) <= 3.0) {
				i++;
				j--;
				count++;
			} else {
				j--;
				count++;
			}
			if (i == j) {
				count++;
				break;
			}
		}

		return count;

	}

	public static void main(String[] args) {
		List<Float> weight = new ArrayList<Float>();
		weight.add((float) 1.01);
		weight.add((float) 1.01);
		weight.add((float) 1.01);
		weight.add((float) 1.4);
		weight.add((float) 2.4);

	System.out.println(efficientJanitor(weight));

	}

}
