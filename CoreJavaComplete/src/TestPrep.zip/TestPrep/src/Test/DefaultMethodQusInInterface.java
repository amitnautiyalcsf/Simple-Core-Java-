package Test;

interface A 
{

	default void disp()
	{
		System.out.println("This is a Method of A");
	}

}

interface M extends A
{

	default void disp()
	{
		System.out.println("This is method of B");
	}

}

class C implements A, M
{
	

	
	
	
}


public class DefaultMethodQusInInterface {

	public static void main(String[] args) {
		C obj = new C();
		 obj.disp();
	}
}
