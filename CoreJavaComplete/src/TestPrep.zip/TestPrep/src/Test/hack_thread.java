package Test;


class HackerEarth
{

	public String str = "Java";
	public static void print()
	{
		System.out.println("Inside HackerEarth");
		
	}

}


class Hacker extends HackerEarth
{

	public String str = "Scala";
	public static void print()
	{
		System.out.println("Inside Hacker");
		
	}

	
}

public class hack_thread
{
	public static void main(String[] args) {
		HackerEarth obj1 = new HackerEarth();
		Hacker obj2 = new Hacker();
		
		System.out.println(((HackerEarth)obj2).str);
		
		((HackerEarth)obj2).print();
	}
	
//public void run()
//{
//for(int h =1;h<=3;h++)
//{
//	
//try {
//	
//	Thread.sleep(10);
//}
//
//catch(Exception hackerearth)
//{
//
//	System.out.println("hello");
//}
//
//System.out.println(h+ "");
//}
//
//
//}
//
//public static void main(String[] args) {
//	hack_thread h1 = new hack_thread();
//	hack_thread h2 = new hack_thread();
//h1.setPriority(Thread.MAX_PRIORITY);
//h2.setPriority(Thread.MIN_PRIORITY);
//h1.start();
//
//try {
//	
//	h1.join();
//}
//
//catch(Exception hackerearth)
//{
//System.out.println("hi");
//}
//
//h2.start();
//
//}
}


