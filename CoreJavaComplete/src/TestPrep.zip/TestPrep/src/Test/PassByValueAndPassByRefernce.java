package Test;

public class PassByValueAndPassByRefernce {

	public  void method(someInner1 i1 , someInner1 i2)
	{
		i1 = new someInner1("C");
		
		System.out.println(i1);
		i2.name= "D";
		
	}
	
	
	public static void main(String[] args) {
		PassByValueAndPassByRefernce obj = new PassByValueAndPassByRefernce();
		someInner1 i1 = new someInner1("A");
		someInner1 i2 = new someInner1("B");
		
		System.out.println(i1+ "-" +i2) ;
		
		obj.method(i1, i2);
		
		System.out.println(i1+ "-" +i2);
		
		
		
	}
	
public static class someInner1
{

	 String name;
	
	public someInner1(String name) {
		this.name= name;
	}

	@Override
	public String toString() {
		return "someInner1 [name=" + name + "]";
	}
	
	

}
	
	
}
	
	



