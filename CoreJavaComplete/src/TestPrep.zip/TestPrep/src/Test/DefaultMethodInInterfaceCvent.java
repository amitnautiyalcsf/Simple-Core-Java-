package Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

interface As {
	
	default void method()
	{
		System.out.println("This is A ");
	}
}

interface Bs{
	
	default void method()
	{
		System.out.println("This is B ");
	}
}




interface Ds extends As
{

	default void method()
	{
		System.out.println("This is D");
	}

}

interface Es extends As
{

	default void method()
	{
		System.out.println("This is E");
	}

}

//public class DefaultMethodInInterfaceCvent implements A, B {
//	public static void main(String[] args) {
//		 new DefaultMethodInInterfaceCvent().method();
//		 
//		 
//		 
//	}
	
	
	
	public class DefaultMethodInInterfaceCvent implements As, Bs, Ds,Es {

		public void method() {

			System.out.println("This is main class method");
		}

		public static void main(String[] args) {
			DefaultMethodInInterfaceCvent obj = new DefaultMethodInInterfaceCvent();
			
			obj.method();
			
			
			List<String> al =Arrays.asList("A", "B","BB","CCC", "A","BB"); 
			
			Map<String, Integer> m1 = al.stream().collect(Collectors.toMap(Function.identity(), String::length));
			
			System.out.println(m1.get("A"));
			System.out.println(m1.get("B"));
			System.out.println(m1.get("BB"));
			System.out.println(m1.get("CCC"));
			
			
		}

		
		
}

