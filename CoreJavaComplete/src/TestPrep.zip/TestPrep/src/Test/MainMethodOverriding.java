package Test;





public class MainMethodOverriding {

	public static void main(String[] args) {
		System.out.println("This is a main method");
		
	MainMethodOverriding obj = new B();
	System.out.println("Enter into this");
	 obj.main(args);
		
		
	}
}
	
	
//	class MainMethodOverriding1  {
//
//		public static void main(String[] args) {
//			System.out.println("This is a main method1");
//			
//		MainMethodOverriding obj = new B();
//		 obj.main(args);
//			
//			
//		}	
//}
	
class B extends MainMethodOverriding  {
		
		public static void main(String[] args) {
			System.out.println("This is a overriden main method");
		}
		
		
	}

