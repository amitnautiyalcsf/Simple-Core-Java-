package Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LongestCommonSubStringTest {
	
	public static int longestSeq(String str)
	{
		
		char[]data = str.toCharArray();
		int i =0;
		int maxi =0;
		
		List[] arraysOfLists = new ArrayList[2];
		
		Map<Character, Integer> h1 = new HashMap<Character, Integer>();
		
		
		for(int j =0 ;j<data.length;j++)
		{
			if(h1.containsKey(data[j]))
			{
			i = Math.max(i, h1.get(data[i])+1);
			
			}
			
			h1.put(data[j], j);
			
			maxi= Math.max(maxi, j-i+1);
			
		}
		
		return maxi;
	}
	
	public static void main(String[] args) {
		String str = "geeksforgeeks";
		System.out.println(longestSeq(str));
				
		
	}

}
