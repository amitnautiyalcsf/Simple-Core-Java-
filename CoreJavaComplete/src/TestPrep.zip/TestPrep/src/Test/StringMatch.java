package Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringMatch {
	
	
	int getValue()
	{
		
		int returnValue=10;
		try {
			
			String[] Languages = {"Java","Ruby"};
			System.out.println(Languages[5]);
		}
		
		catch(Exception e)
		{
			System.out.println("Catch Block :" + returnValue);
			return returnValue;
		}
		
		finally {
			
			returnValue+=10;
			System.out.println("Finally Block :" + returnValue);
			//return returnValue;
		}
		
		return returnValue;
	}
	
	public static void main(String[] args) {
		StringMatch var = new StringMatch();
		System.out.println("Main Block: " + var.getValue());
	}
	
//	static void charNum(String inputString)
//	{
//		
//		HashMap<Character, Integer>charMap= new HashMap<Character, Integer>();
//		char[] strArray = inputString.toCharArray();
//		for(char c :strArray)
//		{
//			
//			if(charMap.containsKey(c))
//			{
//				
//				charMap.put(c, charMap.get(c)+1);
//				
//			}
//			
//			else {
//				charMap.put(c, 1);
//			}
//		}
//		
//		
//		Set<Character> charsInString = charMap.keySet();
//		
//		for(Character ch : charsInString)
//		{
//			
//			if(charMap.get(ch)>1)
//			{
//				System.out.println(ch +" : "+ charMap.get(ch));
//			}
//		}
//		
//		
//	}
//	
//	
//	public static void main(String[] args) {
//	
//		charNum("JavaJ2Ee");
//		
//	}
//	
	
	
//	public static void main(String[] args){
//		ArrayList list = new ArrayList();
//		list.add("Alice");
//		list.add(Boolean.TRUE);
//		list.add(1,"Bob");
//		list.remove("true");
//		list.add(1, "Mike");
//		list.add(4, "Tara");
//		System.out.println(list);
//		
//	}

}
	

//	public void display()
//	{
//		
//	List<String>list = new ArrayList<String>();
//	list.add("Alice");
//	list.add("Smith");
//	list.add("Jones");
//	
//	for(String str: list)
//	{
//		str +="50";
//		
//	}
//	System.out.println(list);
//		
//	}
//	
//	public static void main(String[] args) {
//		
//		StringMatch obj = new StringMatch();
//		obj.display();
//		
//		
//	}
	//}
//		String regex = "\\b(\\d{3}\\d{7}\\b";
//		Pattern p = Pattern.compile(regex);
//		String source ="3342449027 , 2339829, and 6152534734";
//		
//		Matcher m = p.matcher(source);
//		while(m.find())
//		{
//			
//			String val = m.group();
//			String val2 = m.group(1);
//			System.out.println("Val: " + val + ", Val2: " +val2);
//		}
//				
//	}

