package Test;

import java.util.Arrays;

public class ArrayDiffIsMiniMum {

	public static void diffMin(int arr[])
	{
		
		Arrays.sort(arr);
		int sum = Integer.MAX_VALUE;
		int first=0;
		int last=0;
		
		for(int i =0; i<arr.length-1; i++)
		{
			int j =i+1;
			
			int count =arr[j]-arr[i];
			if(count<sum)
			{
				sum =count;
				first=arr[i];
				last=arr[j];
			}
				
				
	
		}
		
		System.out.println(sum);
		System.out.println(first);
		System.out.println(last);
		
		
	}
	
	
	public static void main(String[] args) {
    // 1,4,8,13,15,19,20,22,27
		
		int arr[]= {19,22,27,4,1,15,13,20,8};
		
		diffMin(arr);
		
		
}
}
