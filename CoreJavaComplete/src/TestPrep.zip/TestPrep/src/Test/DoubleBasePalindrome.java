package Test;

import java.util.Stack;

public class DoubleBasePalindrome {

	static int getSumOfDoubleBasePalindrome(int maximum)
	{
		int count = 0;
		for(int i =1; i <= maximum; i++)
		{
			int no = i;
			StringBuffer sb1 = new StringBuffer();

			while(no!=0)
			{
				int r = no%2;
				sb1.append(r);
				no = no/2;
			}
			
			String check1 = sb1.toString();
			StringBuffer check = sb1.reverse();
			
			if(check1.contains(check))
			{
				count = count +i;
			}
			
		}
		
		return count;
		
	}
	
	public static void main(String[] args) {
		System.out.println(getSumOfDoubleBasePalindrome(5));
		
}
	
}
