package Test;

import java.util.HashSet;

public class CheckForAPairWithGivenSum {

	public static void main(String[] args) {
		
		int arr[]= { 1, 4, 45, 6, 10, 8 };
		int sum =16;
		
		HashSet<Integer> s1 = new HashSet<Integer>();
		for(int i =0; i <arr.length;i++)
		{
		
			int temp=sum-arr[i];
			if(s1.contains(temp))
			{
				System.out.println(arr[i]+ " " +temp);
			}
			
			s1.add(arr[i]);
			
			
			
		}
	}
}
