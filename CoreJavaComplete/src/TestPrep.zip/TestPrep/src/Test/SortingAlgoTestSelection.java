package Test;

public class SortingAlgoTestSelection {

	public static void selectSort(int arr[]) {

		for (int i = 0; i < arr.length; i++) {
			int mini = i;
			for (int j = i + 1; j < arr.length; j++) {

				if (arr[j] < arr[mini]) {
					mini = j;
				}
			}

			selectSortswap(arr, i, mini);
		}

	}

	public static void selectSortswap(int arr[], int i, int mini) {
		int temp = arr[mini];
		arr[mini] = arr[i];
		arr[i] = temp;
	}

	public static void insertSort(int arr[]) {

		for (int i = 1; i < arr.length; i++) {
			int temp = arr[i];
			int j = i - 1;

			while (j >= 0 && arr[j] > temp) {
				arr[j + 1] = arr[j];
				j--;
			}

			arr[j + 1] = temp;
		}

	}

// MergeSort

	public void mergeSort(int inputArray[], int start, int end) {

		if (start < end) {
			int mid = (start + end) / 2;

			mergeSort(inputArray, start, mid);
			mergeSort(inputArray, mid + 1, end);
			merge(inputArray, start, mid, end);

		}

	}

	public void merge(int inputArray[], int start, int mid, int end) {

		int tempArray[] = new int[end - start + 1];
		int i = start;
		int j = mid + 1;
		int k = 0;

		while (i <= mid && j <= end) {

			if (inputArray[i] < inputArray[j]) {
				tempArray[k] = inputArray[i];
				i++;
			}

			else {
				tempArray[k] = inputArray[j];
				j++;
			}
			k++;

		}
		if (i <= mid) {
			while (i <= mid) {
				tempArray[k] = inputArray[i];
				i++;
				k++;
			}
		} else if (j <= end) {
			while (j <= end) {
				tempArray[k] = inputArray[j];
				j++;
				k++;

			}
		}

		for (int s = 0; s < tempArray.length; s++) {
			inputArray[start + s] = tempArray[s];

		}

	}

	public void quickSort(int arr[], int l, int h) {

		if (l < h) {
			int p = partition(arr, l, h);
			quickSort(arr, l, p - 1);
			quickSort(arr, p + 1, h);

		}

	}

	public int partition(int arr[], int l, int h) {
		int pivot = arr[l];
		int i = l;
		int j = h;

		while (i < h) {

			while (arr[i] <= pivot && i <= h - 1) {
				i++;
			}

			while (arr[j] > pivot && j >= l) {
				j--;

			}
			if (i < j) {
				swap(arr, i, j);

			}
		}
		swap(arr, j, l);
		return j;
	}

	public static void swap(int arr[], int first, int second) {

		int temp = arr[first];
		arr[first] = arr[second];
		arr[second] = temp;

	}

	public static void bubbleSort(int arr[])
	{
		boolean swapped= false;
		
		for(int i =0; i <arr.length; i++)
		{
			for(int j = i+1; j <arr.length; j++)
			{
				if(arr[j]<arr[i])
				{
					int temp = arr[j];
					arr[j]= arr[i];
					arr[i]= temp;
					swapped = true;
				}
				
			}
			
			if(swapped ==false)
			{

				break;
			}
			
		}
	}

	public static void main(String[] args) {
		int arr[] = { 23, 12, 423, 4, 1, 55, 4, 32, 76 };
		int arr1[] = { 23, 512, 423, 43, 21, 55, 4, 12, 6 };
		int arr2[] = { 223, 212, 423, 343, 121, 55, 4, 122, 60 };
		int arr3[] = {560,23,2291,329,430,320000,12,1,6};
		
		int arr4[] = {560,23,2291,329,430,320000,12,1,6};
		
		selectSort(arr);
		insertSort(arr1);

		for (int x : arr) {
			System.out.println(x);
		}

		System.out.println(" ");

		for (int x : arr1) {
			System.out.println(x);
		}

		System.out.println(" ");

		SortingAlgoTestSelection obj = new SortingAlgoTestSelection();
		obj.mergeSort(arr2, 0, arr2.length - 1);

		for (int x : arr2) {
			System.out.println(x);
		}

		System.out.println(" ");

		obj.bubbleSort(arr3);

		for (int x : arr3) {
			System.out.println(x);
		}
		
		
		System.out.println("");
		
		obj.quickSort(arr4, 0, arr4.length-1);
		
		for (int x : arr4) {
			System.out.println(x);
		}
		
	}

}
