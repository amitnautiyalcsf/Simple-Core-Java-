package Test;

public class SelectionSortTest {
	
	public static void sort(int arr[])
	{
		
		for(int i =0;i<arr.length;i++)
		{
			int minimum= i;
			for(int j =i+1; j<arr.length;j++)
			{

				if(arr[j]<arr[minimum])
				{
					minimum = j;
				}
			
		 }
			
			swap(arr, minimum, i);
			
			
		
	}

}
	
	public static void swap(int arr[] , int minimum, int i)
	{
		
		int temp = arr[minimum];
		arr[minimum]= arr[i];
		arr[i]= temp;
	}
	
	public static void main(String[] args) {
		int arr[] = {24,76,43,1,89,55,33,2};
	
		sort(arr);
		
		for(int x : arr)
		{

			System.out.println(x);
			
		
	}
}
}
