package Test;

public class DecimalToBinary {
public static void main(String[] args) {
	int i = 2;
	
	StringBuffer sb = new StringBuffer();
	while(i!=0)
	{
		int r = i%2;
		sb.append(r);
		i = i/2;
		
	}
	
	System.out.println(sb.reverse());
}


}
