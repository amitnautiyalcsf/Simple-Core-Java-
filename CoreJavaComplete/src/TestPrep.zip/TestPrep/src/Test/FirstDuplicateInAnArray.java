package Test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class FirstDuplicateInAnArray {

	public static void firstDuplicate(int arr[])
	{
		Map<Integer, Integer> m1 = new LinkedHashMap<Integer, Integer>();	
		
		for(int i =0; i <arr.length; i++)
		{
			if(m1.containsKey(arr[i]))
			{
				m1.put(arr[i],m1.get(arr[i])+1);
				
			}
			else {
			m1.put(arr[i],1);
			}
		}
		
		for(Map.Entry<Integer,Integer> x: m1.entrySet())
		{
		//	System.out.println(x.getKey() + "" + x.getValue());
		if(x.getValue()==1)
			{
               System.out.println(x.getKey());
               break;
            }
	    }
	
	}
	public static void main(String[] args) {
		
		int arr[] = {1,3,4,1,4,2,3,5,6,6,4,5,7,4,3};
		
		firstDuplicate(arr);
	}
}
