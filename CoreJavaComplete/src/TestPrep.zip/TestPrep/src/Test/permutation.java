package Test;

public class permutation {
	
	public void permi(String fixed, String sub)
	{
		if(sub.equals(""))
		{
			System.out.println(fixed);
		}
		else {
			int arr[] = new int[256];
			
			for(int i =0;i <sub.length();i++)
			{
				if(arr[sub.charAt(i)]==0)
				{
					arr[sub.charAt(i)]=1;
					
				permi(fixed+ sub.charAt(i), 
						sub.substring(0,i )+ sub.substring(i+1, sub.length()));	
					
				}
				
			}
			
			
		}
		
	}
	
	public void permi(String input)
	{
		
		permi("",input);
		
	}
	
	
	public static void main(String[] args) {
		permutation p = new permutation();
		p.permi("123");
		
		
	}
}
	

