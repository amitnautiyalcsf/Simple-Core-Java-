package Test;

class Solution {
    int MissingNumber(int array[], int n) {
        
    	int sum =0;
    	
    	 for(int i =0; i<n-1;i++){
             sum = sum + array[i];
         }
         int ans = ((n+1)*n)/2-sum; 
         
          
         
         return ans;
}
}



public class MissingElementInUnSortedArray {
public static void main(String[] args) {
	Solution obj = new Solution();
	
	int arr[] = {6,1,2,8,3,4,7,10,5};
	
//	int arr[] = {2};
	int n = arr.length+1;
	
	int x = obj.MissingNumber(arr, n);
	
	System.out.println(obj.MissingNumber(arr, n));
}
}
