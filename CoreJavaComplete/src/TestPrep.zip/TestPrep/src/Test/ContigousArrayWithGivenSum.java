package Test;

//Kadane's Algorithm

public class ContigousArrayWithGivenSum {

	public static void main(String[] args) {
		
		
		int arr[] = {-2, -3, 4, -1, -2, 1, 5, -3};
		
		int arr1[]= {-1,-2,-3,-4};
		
		int sum = Integer.MIN_VALUE;
		int curr_Sum =0;
		int s=0;
		int end=0;
		int start =0;
		
		for(int i =0; i < arr.length;i++)
		{
			
			curr_Sum = curr_Sum+ arr[i];
			if(curr_Sum>sum)
			{
				
				sum = curr_Sum;
				start =s;
				end= i;
				
			}
			
			if(curr_Sum<0)
			{
				curr_Sum=0;
				s = i+1;
			}
			
		}
		
		System.out.println(sum);
		System.out.println(s);
		System.out.println(end);
		
	}
	
	
	
}
