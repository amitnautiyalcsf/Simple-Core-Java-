package Test;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class StreamMapReduceFilterFindFirstOrElse {
	public static void main(String[] args) {
		List<Integer> values = Arrays.asList(12,10,5,3,20,2,18,15);
		
	// Internal Iteration 
		values.forEach(i->System.out.println(i));
		
		System.out.println("");
		
		
	// Method reference
		values.forEach(System.out::println);
		
		System.out.println("");
		
	Stream s1 = values.stream();
	
	
			

	Function<Integer, Integer> f1 = new Function<Integer, Integer>() {
		
		@Override
		public Integer apply(Integer t) {
			return t*2;
		}
	};
	
	Stream s2 = s1.map(f1);
	
	//int result = s2.reduce(obj, )
			
	BinaryOperator<Integer> b1 = new BinaryOperator<Integer>() {

		@Override
		public Integer apply(Integer t, Integer u) {
			// TODO Auto-generated method stub
			return (t+u);
		}
	};
		
	
	int result = (int)s2.reduce(0,b1);
	
	System.out.println(result);
	
	System.out.println("");
	
	System.out.println(values.stream().map(i->i*2).reduce(0,(t,u)->t+u));

	
	Predicate<Integer> p1 = new Predicate<Integer>() {
		
		@Override
		public boolean test(Integer t) {
			// TODO Auto-generated method stub
			return (t%5==0);
		}
	};

	
System.out.println(values.stream().filter(p1).map(f1).findFirst().orElse(0));	

	
	
	System.out.println("");
	
	System.out.println(values.stream().filter(i->i%5==0).map(i->i*2)
			.findFirst().orElse(0));
		
	
	}

}
