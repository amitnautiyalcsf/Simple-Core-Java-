import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class RemoveDuplicatesFromStringAndPrintthose {
	
	public static Map<Character,Integer> printDuplicatesFreq(String str)
	{
		char[] temp = str.toCharArray();
		
		Map<Character, Integer> m1 = new LinkedHashMap<Character,Integer>();
		
		for(int i=0;i<temp.length;i++)
		{
			if(m1.containsKey(temp[i]))
			{
				m1.put(temp[i], m1.get(temp[i])+1);
			}
			
			else {
				m1.put(temp[i], 1);
			}
		}
		
		return m1;
		
		
		
		
	}
	
	
	
	public static void main(String[] args) {
		List<Character>s1 = new LinkedList<Character>();
		
		String str = "AmmyNautiyal";
			
		char temp[] = str.toCharArray();

		for(int i =0;i<temp.length;i++)
		{
			
			if(s1.contains(temp[i]))
			{
				System.out.println(temp[i]);
			}
			
			s1.add(temp[i]);
		}
		
		System.out.println(" ");
		
		Map<Character,Integer> m3 = new LinkedHashMap<Character,Integer>();
		m3= printDuplicatesFreq(str);
		
		for(Map.Entry<Character, Integer>m1 : m3.entrySet())
		{
			if(m1.getValue()>1) {
			System.out.println(m1.getKey()+ " " + m1.getValue());
			}
		}

}
}
