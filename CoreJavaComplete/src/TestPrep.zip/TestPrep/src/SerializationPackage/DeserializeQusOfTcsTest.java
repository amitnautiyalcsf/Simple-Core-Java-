package SerializationPackage;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class DeserializeQusOfTcsTest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) throws Exception {
		FileInputStream fis = new FileInputStream("C:\\Users\\anautiy3\\Documents\\DB\\def.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		SerilaizationTCsQus obj = (SerilaizationTCsQus) ois.readObject();
		
		obj.disp();
	// Compile time error that method is undefined	obj.test();
		obj.show();
		
		
	}

}
