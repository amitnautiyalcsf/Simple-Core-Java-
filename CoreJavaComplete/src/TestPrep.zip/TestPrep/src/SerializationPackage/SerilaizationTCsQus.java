package SerializationPackage;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerilaizationTCsQus implements Serializable {

	
	
	/**
	 * 
	 */
//	private static final long serialVersionUID = 1L;

	public void disp()
	{
		System.out.println("This is a disp method");
		
	}
	
	public void  show()
	{
		System.out.println("This is a show method");
	}
	
//	public void test()
//	{
//		System.out.println("This is a test class");
//	}
	
	public static void main(String[] args) throws Exception{
		SerilaizationTCsQus obj = new SerilaizationTCsQus();
		FileOutputStream fos = new FileOutputStream("C:\\Users\\anautiy3\\Documents\\DB\\def.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(obj);
		
	}

}
