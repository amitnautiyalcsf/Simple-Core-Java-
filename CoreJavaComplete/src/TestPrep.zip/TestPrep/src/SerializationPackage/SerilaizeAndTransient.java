package SerializationPackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerilaizeAndTransient implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	int i =10;
	int j =20;
	
	transient int k= 30;
	transient static int l=40;
	transient final int m=50;
	transient volatile int n =60;
	
	
	public static void main(String[] args) throws Exception {
		SerilaizeAndTransient obj = new SerilaizeAndTransient();
		FileOutputStream fos = new FileOutputStream("C:\\Users\\anautiy3\\Documents\\DB\\abc.txt");
		ObjectOutputStream obs = new ObjectOutputStream(fos);
		obs.writeObject(obj);
		
		
		
		//Deserialization
		
		FileInputStream fis = new FileInputStream("C:\\Users\\anautiy3\\Documents\\DB\\abc.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		SerilaizeAndTransient obj1 = (SerilaizeAndTransient) ois.readObject();
		System.out.println(obj1.i);
		System.out.println(obj1.j);
		System.out.println(obj1.k);
		System.out.println(obj1.l);
		System.out.println(obj1.m);
		System.out.println(obj1.n);
		
		
		
		
		
		
		
		
	}

}
