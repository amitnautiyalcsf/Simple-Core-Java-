package StrategyDesignPattern;

public interface Shape {
	public void draw();

}

// interface expose 


//methods logic hid 