package StrategyDesignPattern;

public class DriverClass {

	public static void main(String[] args) {
		Context context = new Context(new Circle());
		Context context1 = new Context(new Square());
		Context context2 = new Context(new Rectangle());
		context.executeShape();
		context1.executeShape();
		context2.executeShape();
		

		
	}
}
