package StrategyDesignPattern;

public class Context {

	Shape shape;
	
	public Context(Shape shape) {
		this.shape=shape;
		
	}
	
	
	public void executeShape()
	{
		
		shape.draw();
		
	}
	
	
}
