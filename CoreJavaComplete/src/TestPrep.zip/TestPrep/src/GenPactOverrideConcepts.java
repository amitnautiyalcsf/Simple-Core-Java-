
class App {
	
	public String print(String print ,String check)
	{
		return print;
		
	}
	
}



public class GenPactOverrideConcepts extends App{
	
	public String print(String print)
	{
		return "A";
	}

	public static void main(String[] args) {
		App obj = new GenPactOverrideConcepts();
		
		obj.print("A");
		
		
	}
	
}
