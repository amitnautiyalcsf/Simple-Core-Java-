package DataStructure;

class Node
{

	int key ;
	String value;
	Node 

}


public class BSTTree {

}
