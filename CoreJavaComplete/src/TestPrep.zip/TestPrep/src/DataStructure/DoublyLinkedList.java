package DataStructure;

class Nodeo
{

	
	int data;
	Nodeo next =null;
	Nodeo previous= null;
	
	public void display()
	{
		
		System.out.println("["+data+"]");
	}
	
}


















//class Nody{
//	
//	Nody next= null;
//	Nody previous = null;
//	int data;
//	
//	public void display()
//	{
//		System.out.println("["+data+"]");
//		
//	}
//	
//}

// Insert first , InsertLast, Insert after , delete first, deletelast, deletekey,

public class DoublyLinkedList {
	
	public static void main(String[] args) {
		
		
		
		
	}
}












//
//class Nodedoubly
//{
//
//	Nodedoubly next =null;
//	Nodedoubly previous =null;
//	int data;
//	
//	public void display()
//	{
//
//
//	//	System.out.println("{"+data+"}");
//		System.out.println("{"+data+"}");
//
//}
//}
//
////Operations : Insert First, InsertLast, delete first, deleteLast, delete key, 
////insertafter, displayBackward, DisplayForward
//
//public class DoublyLinkedList {
//		
//	static private Nodedoubly first=null;
//	static private Nodedoubly last= null;
//	
//	public static boolean isEmpty()
//	{
//		return first==null;
//		
//	}
//	
//	public static void insertFirst(int data)
//	{
//		Nodedoubly newNode = new Nodedoubly();
//		newNode.data= data;
//		if(isEmpty())
//		{
//			last= newNode;
//			
//		}
//		
//		else {
//			first.previous= newNode;
//			
//		}
//		newNode.next= first;
//		first = newNode;
//	}
//	
//	public static void insertLast(int data)
//	{
//		Nodedoubly newNode = new Nodedoubly();
//		newNode.data= data;
//		
//		if(isEmpty())
//		{
//			
//			first= newNode;
//			
//		}
//		else {
//			
//			last.next= newNode;
//			newNode.previous =last;
//			last = newNode;
//			
//		}
//		
//	}
//	
//	public static void insertAfter(int key, int data)
//	{
//		
//		Nodedoubly newNode = new Nodedoubly();
//		newNode.data= data;
//		Nodedoubly current =first;
//		
//		while(current.data!=key)
//		{
//			current= current.next;
//			
//			if(current==null) {
//				return;
//			}
//			
//			if(current== last)
//			{
//				
//				current.next = newNode;
//				last= newNode;
//			}
//			else
//			{
//			
//				newNode.next= current.next;
//				current.next.previous= newNode;
//				
//			}
//			
//			newNode.previous=current;
//			current.next = newNode;
//			
//		}
//		
//		
//	}
//	
//	public static int deletefirst()
//	{
//		int temp = first.data;
//		if(first.next==null)
//		{
//	
//			last= null;
//			
//		}
//		first.next.previous=null;
//		
//		first = first.next;
//		
//		return temp;
//		
//	}
//	
//	public static int deleteLast()
//	{
//		int temp = last.data;
//		if(first.next==null)
//		{
//			first= null;
//		}
//		
//		else {
//			
//			
//			last.previous.next =null;
//		}
//		
//		last = last.previous;
//		
//		return temp;
//	}	
//	
//	public static void displayForward()
//	{
//		System.out.println("Displaying forward list first----------> Last");
//		
//		Nodedoubly current = first;
//		while(current!=null)
//		{
//			current.display();
//			current= current.next;
//			
//			
//		}
//		System.out.println(" ");
//		
//	}
//	
//	public  static void displayBackward()
//	{
//		System.out.println("Displaying In backward Direction  last---------> first");
//		
//		Nodedoubly current = last;
//		
//		while(current!=null)
//		{
//			
//			current.display();
//			current= current.previous;
//			
//		}
//		System.out.println("");
//		
//	}
//	
//	
//	public static Nodedoubly deleteKey(int key)
//	{
//		
//		Nodedoubly temp = first;
//		while(temp.data!= key)
//		{
//			
//			temp = temp.next;
//			if(temp==null)
//			{
//				
//				return null;
//				
//			}
//			
//		}
//		
//		if(temp==first)
//		{
//			
//			first = first.next;
//		}
//		
//		else {
//			
//			temp.previous.next= temp.next;
//		}
//		
//		if(temp== last)
//		{
//			last= temp.previous;
//		}
//		else {
//			
//			temp.next.previous = temp.previous;
//		}
//		
//		return temp;
//	}
//	
//	
//	public static void main(String[] args) {
//		insertFirst(10);
//		insertFirst(20);
//		insertFirst(30);
//		insertFirst(40);
//		
//		displayForward();
//		displayBackward();
//		
//		
//		insertLast(90);
//		displayForward();
//		displayBackward();
//		
//		
//		insertAfter(30, 110);
//		
//		displayForward();
//		displayBackward();
//		
//		
//		deletefirst();
//		displayForward();
//		displayBackward();
//		
//		
//		deleteLast();
//		
//		displayForward();
//		displayBackward();
//		
//		deleteKey(110);
//		
//		displayForward();
//		displayBackward();
//		
//		
//	}
//}
