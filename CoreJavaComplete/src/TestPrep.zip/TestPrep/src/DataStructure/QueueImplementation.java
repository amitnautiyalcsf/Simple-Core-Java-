package DataStructure;

public class QueueImplementation {
	
	private int maxSize;
	private int front;
	private int rear;
	private int nitems;
	private int arr[];
	
	public QueueImplementation(int size) {
		
		this.maxSize = size;
		this.front=0;
		this.rear=-1;
		this.nitems=0;
		this.arr= new int[maxSize];
	}
	
	
	public boolean isEmpty()
	{
		return nitems==0;
		
	}
	
	public boolean isfull()
	{
		
		return nitems==maxSize;
	}
	
	
	public void insert(int data)
	{
		
		if(isfull())
		{
			
			rear= -1; // overriden approach of circular Queue.
 		}
		
		rear ++;
		arr[rear]= data;
		nitems++;
		
		
	}
	
	public int remove()
	{
		
		int data = arr[front];
		front++;
		if(front== maxSize-1)
		{
			front=0;
		}
		
		nitems--;
		
		return data;
		
	}
	
	public int peek()
	{
		return arr[front];
		
	}
	
	public void view()
	{
		for(int x: arr)
		{
			System.out.println(x);
		}
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
		QueueImplementation obj = new QueueImplementation(4);
		obj.insert(1);
		obj.insert(5);
		obj.insert(9);
		obj.insert(10);
		
		
		obj.view();
		obj.peek();
		obj.remove();
		obj.view();
		obj.peek();
		
	}
	
	
	
	
//	private int maxSize;
//	private int rear;
//	private int front;
//	private int nitems;
//	private long [] queueArray;
//	
//	
//	public QueueImplementation(int size) {
//		this.maxSize = size;
//		this.rear =-1;
//		this.front=0;
//		this.queueArray = new long[maxSize];
//	}
//	
//	
//	public void insert(long data)
//{
//		if(rear == maxSize-1)
//		{
//			
//			rear =-1;  // overridder approach circular queue
//		}
//		
//		rear = rear+1;
//		queueArray[rear] = data;
//		nitems++;
//		
//		
//}
//	
//	public long remove()
//	{
//	
//		long data = queueArray[front];
//		front++;
//		if(front == maxSize)
//		{
//			
//			front =0; // circular queue apprach
//		}
//		
//		nitems-- ;
//		return data;
//		
//	}
//	
//	
//	public boolean isEmpty()
//	{
//		
//		return nitems==0;
//	}
//	
//	
//	public boolean isfull()
//	{
//		
//		return nitems == maxSize;
//	}
//	
//	public long peek()
//	{
//		
//		return queueArray[front];
//	}
//	
//	public void view()
//	{
//		
//		for(int i =0; i<queueArray.length; i++)
//		{
//			
//			System.out.println(queueArray[i] );
//		}
//	}
//
//	
//	
//	public static void main(String[] args) {
//		QueueImplementation q = new QueueImplementation(7);
//		q.insert(9);
//		q.insert(10);
//		q.insert(13);
//		q.insert(19);
//		q.insert(20);
//		q.insert(18);
//		q.insert(12);
//		
//	
////	System.out.println(q.peek());
//	
//	System.out.println(q.remove());
//	
//	
//	
//	q.view();
//	
//	
//	}
}
