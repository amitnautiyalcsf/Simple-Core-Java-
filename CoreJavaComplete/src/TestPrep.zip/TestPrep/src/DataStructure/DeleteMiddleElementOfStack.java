package DataStructure;

import java.util.Stack;

public class DeleteMiddleElementOfStack {

	public static void deleteMiddleElement(Stack<Integer>st, int temp, int n)
	{
		if(st.empty() || temp ==n)
			return ;
		
		int x = st.pop();
		deleteMiddleElement(st, temp+1, n);
		
		if(temp!=n/2)
			st.push(x);
		
		
	}	
	public static void main(String[] args) {
		
		Stack<Integer>st = new Stack<Integer>();
		st.push(1);
		st.push(2);
		st.push(3);
		st.push(4);
		st.push(5);
		
		deleteMiddleElement(st, 0, st.size());
		
		while(!st.isEmpty())
		{
			System.out.println(st.pop());
		}
		
		
		
	
}
}
