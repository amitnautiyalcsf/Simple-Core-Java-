package DataStructure;

public class ReverseAStringUsingStack {
	private int maxSize;
	private int top;
	private char arr[];
	
	
	public ReverseAStringUsingStack(int size) {
		this.maxSize=size;
		this.top=-1;
		this.arr = new char[maxSize];
		
	}
	
	
	public boolean isEmpty()
	{
		
		return top==-1;
	}
	
	
	public boolean isFull()
	{
		return top== maxSize-1;
	}
	
	
	public void push(char data)
	{
		
		if(isFull())
		{
			
			System.out.println("Cannot insert more elment in stack");
			return;
		}
		
	
		top++;
		arr[top]= data;
				
	}
	
	public char pop()
	{
		
		if(isEmpty())
		{
			
			System.out.println("Stack is empty");
			return 'o';
		}
		
		char data = arr[top];
		top--;
		return data;
		
	}
	
	public static String reverse(String str)
	{
		
		int length = str.length();
		
		ReverseAStringUsingStack rvr = new ReverseAStringUsingStack(length);
		
		for (int i =0;i<str.length();i++)
		{
			char data = str.charAt(i);
			rvr.push(data);
		}
		
		String result = "";
		
		while(!rvr.isEmpty())
		{
			char data = rvr.pop();
		
			result = result + data;
			
		}
		return result;
}
	public static void main(String[] args) {
	
	System.out.println(reverse("AmitNautiyal"));
	
	
	String str = " i am back";

	String[] rsult = str.split("\\s");
			
	for(String x: rsult)
	{
		System.out.println(x);
	}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

//	 private int maxSize;
//	 private char stackArray[] ;
//	 private int top;
//	 
//	 
//	 public ReverseAStringUsingStack(int size) {
//	
//		
//		 this.maxSize= size;
//		 this.top = -1;
//		 this.stackArray = new char[maxSize];
//	}
//	 
//	 public boolean isFull()
//	 {
//		 return (top == maxSize-1);
//		 
//	 }
//	 
//	 public boolean isEmpty()
//	 {
//		 
//		 return (top ==-1);
//	 }
//	 
//	 public void push(char data)
//	 {
//		 if(isFull()) {
//			 
//			 System.out.println("Value cannt be added in stack");
//		 }
//		 top = top+1;
//		 stackArray[top] = data;
//		 
//		 
//	 }
//	 
//	 public char pop()
//	 {
//		 
//		 if(isEmpty())
//		 {
//			 System.out.println("Stack is empty");
//			 return 'o';
//		 }
//		 
//		 char data = stackArray[top];
//		 top--;
//		 return data;
//	 }
//	 
//	public static String reverseString(String str)
//	{
//		
//		int length = str.length();
//		
//		ReverseAStringUsingStack st = new ReverseAStringUsingStack(length);
//		for(int i =0 ; i<str.length(); i++)
//		{
//			
//			char data  = str.charAt(i);
//			st.push(data);
//			
//		}
//		
//		String result= "";
//		
//		while (!st.isEmpty())
//		{
//			char data = st.pop();
//			
//			result = result + data;
//		}
//		
//		return result;
//		
//				
//	}
//	
//	
//	public static void main(String[] args) {
//	System.out.println(reverseString("Amit Nautiyal"));
//		
//	}
//	
	
}
