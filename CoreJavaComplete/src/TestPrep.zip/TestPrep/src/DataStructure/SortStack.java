package DataStructure;

import java.util.Stack;

public class SortStack {
//
//	10  
//	38
//	9
//	11
//	5    temp
//	4    temp
//	
//	38
//	11
//	9
//	5
//	4
	public static void sortedStack(Stack<Integer>st, int x)
	{
		if(st.isEmpty() || x>st.peek())
		
		{
			
			st.push(x);
			return;
			
			
		}
			
			int temp = st.pop();
			sortedStack(st, x);
		   st.push(temp);

}
	
	
	public static void sortStack(Stack<Integer>st)
	{
		if(st.isEmpty())
			return;
		
			
			int x = st.pop();
			
			sortStack(st);
		sortedStack(st, x);	
			//st.push(x);
		
		
		
	}
	
	
	
	public static void main(String[] args) {
		Stack<Integer>st = new Stack<Integer>();
		st.push(3);
		st.push(8);
		st.push(9);
		st.push(2);
		st.push(10);
		
		sortStack(st);
		
		while(!st.isEmpty())
		{
			System.out.println(st.pop());
		}
	}
	
}
