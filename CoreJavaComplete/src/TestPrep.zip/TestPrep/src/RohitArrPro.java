import java.util.HashMap;
import java.util.Map;

public class RohitArrPro {
public static void main(String[] args) {
	int arr1[] = { 1, 5, 7, -1, 5 };
	int arr2[]= {7,6,5,3,8,7};
	
	int sum= 6;
	
	int count =0;
//	for(int i =0;i<arr1.length;i++)
//	{
//		
//		for(int j=0;j<arr2.length;j++)
//		{
//			
//			int val= arr1[i]+arr2[j];
//			if(val==sum)
//			{
//				count++;
//				
//			}
//	}

	
	Map<Integer,Integer> m1 = new HashMap<>();
	
	for(int x: arr1)
	{
		m1.put(x, m1.getOrDefault(x, 0)+1);
	}
	
	for(int x: arr1)
	{
		
		if(m1.containsKey(sum-x))
		{
			count+= m1.get(sum-x);
			//m1.put(sum-x, m1.get(sum-x)-1);
		}
	}
	
	
	
	System.out.println(count/2);
}
}
