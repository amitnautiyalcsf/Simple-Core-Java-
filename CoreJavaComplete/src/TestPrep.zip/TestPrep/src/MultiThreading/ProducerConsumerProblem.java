package MultiThreading;

import java.util.LinkedList;

class ProducerConsumer
{

	LinkedList<Integer> al = new LinkedList<Integer>();

	int capacity = 2;
	
	public void produce() throws InterruptedException
	{
		
		int value =0;
		while(true)
		{
			synchronized(this)
			{
			
			while(al.size()==2)
			{
				wait();
			}
			System.out.println("Producer produces values" +value);
			
			al.add(value++);
			
			notify();
			
			Thread.sleep(1000);
			}
			
		}
		
	}
	
	public void consume() throws InterruptedException
	{
		while(true)
		{
			synchronized (this) {
				
				while(al.size()==0)
				{
					wait();
				}
				
				int val = al.removeFirst();
				
				System.out.println("Value consumed" + val);
				
				notify();
				Thread.sleep(1000);
				
			}
			
		}
		
	}
			
	

}




public class ProducerConsumerProblem {
 public static void main(String[] args) throws InterruptedException {
	 
	final ProducerConsumer pc = new ProducerConsumer();
	 
	 
	 Thread t1 = new Thread() {
		 
	 public void run()
	 {
		 try {
			pc.produce();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	 }
		
		
	};
	
	
	
	Thread t2 = new Thread() {
		 
		 public void run()
		 {
			 try {
				pc.consume();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		 }
			
			
		};
		
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		
		

	
}
}
