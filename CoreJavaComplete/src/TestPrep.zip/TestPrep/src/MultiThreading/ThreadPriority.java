package MultiThreading;

public class ThreadPriority {
public static void main(String[] args) throws InterruptedException {
	
	Thread t1 = new Thread(()->{
		for(int i =0 ;i<5;i++) {
		System.out.println(Thread.currentThread().getPriority());
	try {

		Thread.sleep(1000);
	}
	catch(Exception e) {}
		}
	},"Hi-Thread");

Thread t2 = new Thread(()->{
	for(int i =0; i<5;i++)
	{
		System.out.println(Thread.currentThread().getPriority());
		try {
			Thread.sleep(1000);

		} catch (Exception e) {
		}
	}
}, "Hello-Thread");


System.out.println(t1.getName());
System.out.println(t2.getName());

t1.setPriority(1);
t2.setPriority(10);

//t1.setPriority(Thread.MAX_PRIORITY);

System.out.println(t1.getPriority());
System.out.println(t2.getPriority());

t1.start();
try {
	
	Thread.sleep(1000);
}
catch(Exception e) {}


t2.start();
t1.join();
t2.join();
}
}



// Thread.yield()----> t1,t2 same priority () - t1.yield will wait t1 ------ same priority ka threaD Execute(t2)


//-- t1. join() 