package MultiThreading;

public class OddEvenNoFromDiffThread {

	
	public static void main(String[] args) {
		
		Thread t1 = new Thread(()->
		 {
			 
			 for(int i =1;i<=10;i++)
			 {
				 if(i%2==0)
				 {
					 System.out.println(i +" " +Thread.currentThread().getName());
				 }
				 
			 }
		 },"Thread1");
		
		Thread t2 = new Thread(()->
		 {
			 
			 for(int i =1;i<=10;i++)
			 {
				 
				 if(i%2==1)
				 {
					 System.out.println(i + " " +Thread.currentThread().getName());
				 }
				 
			 }
		 },"Thread2");
		
		
		t1.start();
		t2.start();
		

		
		
		
		
	}
	
}
