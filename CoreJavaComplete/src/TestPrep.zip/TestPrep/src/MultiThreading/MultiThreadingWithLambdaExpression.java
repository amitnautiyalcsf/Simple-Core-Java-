package MultiThreading;

public class MultiThreadingWithLambdaExpression {

	public static void main(String[] args) {

	Runnable obj1 = new Runnable() {
		
		@Override
		public void run()
		{
		
			System.out.println("This is thread t1" + Thread.currentThread().getName());
			for(int i =0; i <5; i++)
			{
				System.out.println(i);
				
			}
			
		}
		
	};	
	
	Thread t3 = new Thread() {
		@Override
		public void run()
		{
		
			System.out.println("This is thread t3 using thread class");
			for(int i =0; i <5; i++)
			{
				System.out.println(i);
				
			}
			
		}
		
	};
	
	Runnable obj2 = new Runnable() {
		
		@Override
		public void run()
		{
			
			System.out.println("This is thread t2" + Thread.currentThread().getName());
		
			for(int i =0; i <5; i++)
			{
				System.out.println(i);
				
			}
			
		}
		
	};	
	
	Runnable obj5 = ()->System.out.println("This is thread t5" +  Thread.currentThread().getName());
	
obj1.run();
obj2.run();
obj5.run();
t3.start();


// --- yield  same /  or higher /   
//-- join , isAlive(), sleep ,



		
//with anonymous class
//		Runnable obj1 =  new Runnable() 
//				{
//			@Override
//			public void run()
//			{
//			 for(int i= 0; i<=5;i++)
//			 {
//				 System.out.println("Hi");
//				 try {
//					 if(i==2)
//					 {
//						 Thread.sleep(1000);
//						 
//					 }
//					 
//				 }
//				 catch(Exception e)
//				 {
//					 
//				 }
//			 }
//				
//			}
//				
//			};
//			
//			Runnable obj2 = new Runnable() {
//				
//				@Override
//				public void run()
//				{
//
//				for(int i = 0; i<3; i++)
//				{
//				
//					System.out.println("Syonara");
//					try {
//					if(i==2) {
//						
//						Thread.sleep(10000);
//					}
//						
//					}
//					catch(Exception e) {}
//				}
//				}
//			};
//		 obj1.run();
//		 obj2.run();

		// By using lamda expression
		
		
		/*
		 * Thread t1 = new Thread(()-> {
		 * 
		 * for(int i=0 ;i<3 ;i++) { System.out.println("Hi"); try { Thread.sleep(1000);
		 * } catch(Exception e) {} } });
		 * 
		 * Thread t2 = new Thread(()->{ for(int i=0; i<3;i++) {
		 * System.out.println("Syonara"); try { Thread.sleep(1000); } catch(Exception e)
		 * {}
		 * 
		 * } });
		 * 
		 * 
		 * 
		 * t1.start(); try { Thread.sleep(10); } catch (Exception e) { } t2.start();
		 */
}
}
