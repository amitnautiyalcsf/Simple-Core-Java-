package MultiThreading;

import java.util.LinkedList;

public class ProducerConsumerProblemTest {
	
	LinkedList<Integer> al = new LinkedList<Integer>();
	
	
	public void produce() throws InterruptedException
	{
		int value =0;
		while(true)
		{
			synchronized(this)
			{
				
				while(al.size()==2)
				{
					wait();
				}
				
				System.out.println("Produces Value " +value);
				al.add(value++);
				
				notify();
				Thread.sleep(1000);
				
			}
			
			
		}
		
	}
	
	public void consume() throws InterruptedException
	{
		
		while(true)
		{
			synchronized (this) {
				
				while(al.size()==0)
				{
					wait();
				}
				
				int val = al.removeFirst();
				
				System.out.println("Consumes Value " +val);
				
				notify();
				Thread.sleep(1000);
				
			}
		}
		
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		final ProducerConsumerProblemTest test = new ProducerConsumerProblemTest();
		
		Thread t1 = new Thread()
		{
			 public void run()
			 {
				 try {
					test.produce();
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			 }	
			
		};
		
		
		Thread t2 = new Thread()
		{
			 public void run()
			 {
				 try {
					test.consume();
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			 }	
			
		};
			
		t1.start();
		t2.start();
		t1.join();
		t2.join();
			
			
		
		
		
	}
	
	
	
	

}
