package MultiThreading;

public class PrintEvenAndOddinSequenceUsingThread {

	
	static int N =10;
	int counter =1;
	
	public void printEvenNo()
	{
		
		synchronized(this)
		{
		
			while(counter<N)
			{
			
				while(counter%2==0)
				{
					
					try {
						
						wait();
					}
					catch (Exception e) {
						// TODO: handle exception
					}
					
				}
				System.out.println(counter + "" + Thread.currentThread().getName());
				
				counter++;
				notify();
			
			}
	}
}
	
	public void printOddNo()
	{
		
		synchronized(this)
		{
		
			while(counter<N)
			{
			
				while(counter%2==1)
				{
					
					try {
						
						wait();
					}
					catch (Exception e) {
						// TODO: handle exception
					}
					
				}
				System.out.println(counter + "" + Thread.currentThread().getName());
				
				counter++;
				notify();
			
			}
	}
}
	
	
	
	
	public static void main(String[] args) {
		PrintEvenAndOddinSequenceUsingThread obj = new PrintEvenAndOddinSequenceUsingThread();
		
		Thread t1 = new Thread(()-> {
			
			obj.printOddNo();
			
		},"Thread-even-no");
		
		
		Thread t2 = new Thread(()-> {
			
			obj.printEvenNo();
			
		},"Thread-odd-no");
		
		t1.start();
		t2.start();
	}
}
