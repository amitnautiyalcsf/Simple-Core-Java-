package FacadePattern;

public class FacadeSapeMaker {

	Shape circle;
	Shape sqaure;
	Shape rectangle;
	
	public FacadeSapeMaker() {
		circle = new Circle();
		sqaure = new Square();
		rectangle = new Rectangle();
		
	}
	
	public void drawCircle()
	{
		circle.draw();
	}
	
	public void drawsSquare()
	{
		
		sqaure.draw();
	}
	
	public void drawRectangle()
	{
       rectangle.draw();
	}
	
}
