package FacadePattern;

public class DriverClass {
public static void main(String[] args) {
	FacadeSapeMaker  obj  = new FacadeSapeMaker();
	obj.drawRectangle();
	obj.drawCircle();
	obj.drawsSquare();
}
}
