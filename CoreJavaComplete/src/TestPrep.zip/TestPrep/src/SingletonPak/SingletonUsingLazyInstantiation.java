package SingletonPak;

class Atc
{

	//static Atc obj = new Atc(); // Eager approach bcoz we are creating object even without using it and it resides in memory
    static Atc obj ;

    private Atc() {}
    
    static Atc getMyInstance()
    {
    	
    	if(obj == null)
    	{
    		obj = new Atc();
    		
    	}
    	return obj;
    }
}

public class SingletonUsingLazyInstantiation {

	public static void main(String[] args) {
		
		Atc obj2 = Atc.getMyInstance();
		Atc obj3 = Atc.getMyInstance();
		
		System.out.println(obj2);
		System.out.println(obj3);
	
	}
}
