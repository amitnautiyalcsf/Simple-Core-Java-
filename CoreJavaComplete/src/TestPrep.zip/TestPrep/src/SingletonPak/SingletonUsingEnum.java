package SingletonPak;


 // we can call it as specific type of class having private constrctor 



enum Afg{
	
	INSTANCE;
	
	int i ;
	public void show()
	{
		
		System.out.println(i);
	}
	
}

//Advantage of using Enum in Singleton Design pattern is when we talk about deserialization, we have to use readObject();,even if your class is Singleton read
//readObject will give you new Object, and thats why using enum there is a method called as readResolve();, so if we are using this method it will not create new 
//Object , It will use the current object itself

public class SingletonUsingEnum {
	
	public static void main(String[] args) {
		
		Afg obj = Afg.INSTANCE;
		obj.i = 10;
		obj.show();
		
		System.out.println(obj.hashCode());
		
		Afg obj2 = Afg.INSTANCE;
		obj.i= 20;
		obj2.show();
		
		System.out.println(obj2.hashCode());

	
}
}
