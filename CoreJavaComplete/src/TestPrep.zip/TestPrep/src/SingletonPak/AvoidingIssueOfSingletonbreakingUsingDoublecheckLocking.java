package SingletonPak;

import java.util.HashMap;

import MultiThreading.SynchronizedKeyword;

public class AvoidingIssueOfSingletonbreakingUsingDoublecheckLocking {
public static void main(String[] args) {
	Thread t1 = new Thread(()-> {
		
		Pope obj1 = Pope.getMyInstance();
		System.out.println(obj1);
	});
	
	Thread t2 = new Thread(()->{
		 Pope obj2 = Pope.getMyInstance();
		 System.out.println(obj2);
		
	});
	
	t1.start();
	
// why to waste 10 mili sec? use Synchronized block
//	try {
//		t1.sleep(10);
//	}
//	catch(Exception e)
//	{}
	
	t2.start();
	
}
}

class Pope{
	
	static Pope obj ;
	
	private Pope()
	{
		System.out.println("Instance Created successfully");
		
	}
	
//	public static Pope getMyInstance()
//	{
//		if(obj==null) // checking wheather it is the first time we are creating the object. 
//		{
//			synchronized(Pope.class)
//			{
//			if(obj==null)
//			{
//			obj= new Pope();
//			}
//		}
//		
//	}
//		return obj;
//}
	
	
	
	
	
	
	public static Pope getMyInstance()
	{
	
		if(obj==null)
		{
			//t1- t2 
			synchronized(Pope.class)
			{
				
				if(obj==null)
				{
					
					obj = new Pope();
				}
			}
		}
		return obj;
	}
	
	Map <String, String>m1 = new HashMap<String, String>();
	
	
	
	1
	2
	3
	4
	5
	6
	7
	8
	9
	16
	
	
	
	
	
}

