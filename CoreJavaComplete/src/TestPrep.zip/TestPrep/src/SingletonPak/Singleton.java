package SingletonPak;

//Steps to create Singleton class
// 1. static instance of class
// 2. private cons. // so that we can't create its repetetive obj
// 3. static which will give (return) the instance of our class.

class Rto{
	
	static Rto obj= new Rto();  // Eager ApprOACH / Instanstionaiton
	
	private Rto()
	{
		
	}
	
	public static Rto getMyInstance()
	{
		return obj;
		
	}
	
}

public class Singleton {
	public static void main(String[] args) {

		Rto obj1 = Rto.getMyInstance();
		Rto obj2 = Rto.getMyInstance();
	
		System.out.println(obj1);
		System.out.println(obj2);
		
		
		
	}

}
