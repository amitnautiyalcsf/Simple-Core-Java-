package SingletonPak;

public class BreakingSingletonUsingThreading {
public static void main(String[] args) {
	
	
// Here When we use Thread It will create the instance Twice Not a single Instance
//bcoz we are calling both the thread at the same time, which means 
//both entering this section same time. and hence we failed to follow Singleton Design Pattern.

	Thread t1 = new Thread(()-> {
		System.out.println("This is thread t1");
		Ahy obj1 = Ahy.getmyInstance();
		System.out.println(obj1);
	});			
		
	Thread t2 = new Thread(()-> {
		System.out.println("This is thread t2");
		Ahy obj2= Ahy.getmyInstance();
		System.out.println(obj2);
	});
	
	t1.start();
	
	
	
	Thread t3 = new Thread(()-> {
		
		System.out.println("This is T3 thread");
		Ahy obj3 = Ahy.getmyInstance();
		System.out.println(obj3);
	});
	
//	try {
//		t1.sleep(1000);
//		}
//	catch(Exception e) {}
//	
	t2.start();
	t3.start();
	
}
}

class Ahy
{

	//Static isntance
	static Ahy obj ;
	
	// Private constructor
	private Ahy()
	{
		
		System.out.println("Instance created");
	}
	
	// static method which return instance of class
	public static Ahy getmyInstance()
	{
		
		if (obj== null)
		{
			
			obj = new Ahy();
		}
		
		return obj;
	}
	

}


