package SingletonPak;


class Mno{

	static Mno obj;
	private Mno()
	{
		System.out.println("Instnace Created Successfully");
	}
	
	public static synchronized Mno getMyInstance()
	{
		if(obj==null)
		{
			obj= new Mno();
			
		}
		return obj;
		
	}
	
}


public class AvoidingIssueofSingletonWhileUsingThreadsWithSynchronization {
public static void main(String[] args) {
	
	Thread t1 = new Thread(()->{
		
		Mno obj1 = Mno.getMyInstance();
	});
	
	Thread t2 = new Thread(()->{
		Mno obj2 = Mno.getMyInstance();
		
	});
	t1.start();
t2.start();
	
}


	
}
