package ExceptionHandling;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.function.Function;
import java.util.stream.Collectors;

public class tryWithResource {

	public static void main(String[] args) throws IOException {
		int i =0;
		
	try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
	{
		int j = Integer.parseInt(br.readLine());
		System.out.println(j);
	}
	
	
	String str = "Swiss Bank";
	
	String str1 = str.replace(" ", "");
	
	String inputString = "i am a java developer java developer";
	
	
	String[] input = inputString.split("\\s");
	
	HashSet<String>s1 = new LinkedHashSet<String>();
	
	for(String x: input)
	{
		
		s1.add(x);
	}
	
	for(String s : s1)
	{
System.out.println(s);
	}
	
	
	Character ch = str1.chars()
			.mapToObj(k->Character.toLowerCase(Character.valueOf((char)k)))
			.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new, Collectors.counting()))
			.entrySet().stream()
			.filter(entry->entry.getValue()==1)
			.map(entry->entry.getKey())
			.findFirst().get();
			
	System.out.println(ch);
	
	}
}
