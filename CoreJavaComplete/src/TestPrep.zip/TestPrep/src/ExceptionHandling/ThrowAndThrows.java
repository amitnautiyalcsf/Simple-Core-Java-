package ExceptionHandling;

import java.util.LinkedHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ThrowAndThrows {

	public static void dividedByZero(int i)
	{
		int data = i/0;
		throw new ArithmeticException();
		
	}
	
	public static void checkingthrows(int i) throws ArithmeticException
	{
		
		int data= i/0;
	}
	
	public static void main(String[] args) {
		
	//	dividedByZero(10);
		checkingthrows(20);
		

		
		
		
				
				
		
		
		
		
	}
	
}
