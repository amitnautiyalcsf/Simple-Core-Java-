package comparableAndComparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

// comparable: comparing itself with other object
public class Movie implements Comparable<Movie> {
	
	private double rating;
	private String name;
	private int year;
	
	public Movie(double rating, String name, int year) {
		this.rating = rating;
		this.name= name;
		this.year= year;
	}
	
	@Override
	public int compareTo(Movie m) {
		
		return (this.year -m.year);
	}
	
	public double getRating() {
		return rating;
	}

	public String getName() {
		return name;
	}

	public int getYear() {
		return year;
	}

	
// Comparator: instead of sorting it in Single object if i want to sort it out based on collection of objects 
// like here i want to sort based on name and rating as well: have to create New Class	

	
	
	
	public static void main(String[] args) {
		
		List<Movie> m = new ArrayList<Movie>();
		
		m.add(new Movie(3.9,"Force Awakens", 2002));
		m.add(new Movie(4.7,"Star Wars", 1995));
		m.add(new Movie(10.0,"Empire Strikes Back", 1998));
		m.add(new Movie(8.4, "Return of the Jedi",  1983));
		
		
		Thread t1 = new Thread(()-> {});
		Thread t2 = new Thread(()-> System.out.println());
		
		
		Runnable r1 = ()->System.out.println();
		
		Runnable r2 = new Runnable() {
			
			public void run()
			{
				
			}
			
		};
		
		System.out.println();
		
		Collections.sort(m);
		
		System.out.println("Sorted by Year :");
		
		for(Movie x: m)
		{
			System.out.println(x.getRating()+" "+ x.getName() +" "+ x.getYear());
		}
		
		
//		Comparator<Movie> c = new Comparator<Movie>() {
//
//			@Override
//			public int compare(Movie o1, Movie o2) {
//				return o1.getName().compareTo(o2.getName());
//			}
//		};
		
		Collections.sort(m,(o1,o2)->o1.getName().compareTo(o2.getName()));
		
		
		System.out.println("Sorted by Name :");
		
		for(Movie x1: m )
		{
			
			System.out.println(x1.getRating()+" "+ x1.getName() +" "+ x1.getYear());
		}
		
		
		System.out.println("Sorted by Rating :");
		
		Collections.sort(m,(o1,o2)->o1.getRating()<o2.getRating()?1:-1);

		
		for(Movie x3: m )
		{
			
			System.out.println(x3.getRating()+" "+ x3.getName() +" "+ x3.getYear());
		}
		
	
		
}
}
