package comparableAndComparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Candidate implements Comparable<Candidate>
{
	private long id;
	private long rollno;
	private String name;
	
	
	public Candidate(long id, long rollno, String name) {
		this.id = id;
		this.rollno= rollno;
		this.name = name;
	}
	
	
	@Override
	public int compareTo(Candidate c) {
		int roll = (int) (this.rollno-c.rollno);
		return roll;
	}


	public long getId() {
		return id;
	}


	public String getName() {
		return name;
	}
	
	public long getRollno()
	{
		return rollno;
	}
	
	
	public static Comparator<Candidate> c2 = (i,j)->{ return i.getId()>j.getId()? 1:-1;
	};
	
	public static List<Candidate> sortSudent(List<Candidate> l1)
	{
		Collections.sort(l1, Candidate.c2);
		return l1;
		
	}
}


public class SortCandidate {
public static void main(String[] args) {
	List<Candidate> l1 = new ArrayList<Candidate>();
	
	Candidate c1 = new Candidate(1000,3, "Amit");
	Candidate c2 = new Candidate(90,1, "rohit");
	Candidate c3 = new Candidate(900,5, "Ankit");
	
	
	l1.add(c1);
	l1.add(c2);
	l1.add(c3);
	
	Collections.sort(l1);
	
	System.out.println("Sorted by id :");
	
	for(Candidate x: l1)
	{
		System.out.println(x.getId()+" "+ x.getRollno()+ " " + x.getName());
	}
	
	System.out.println("");
	
	Candidate.sortSudent(l1);
	
	for(Candidate x : l1)
	{
		System.out.println(x.getId()+" "+ x.getRollno()+ " " + x.getName());
	}
	
	
//	Comparator<Candidate> co = new Comparator<Candidate>() {
//
//		@Override
//		public int compare(Candidate o1, Candidate o2) {
//			 if(o1.getId()>o2.getId())
//			 {
//				 return 1;
//			 }
//			return 0;
//		}
//	};
	
}
}
