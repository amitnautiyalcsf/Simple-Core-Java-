package WrapperClasses;

public class BoxingUnBoxingAutoBoxing {

	public static void main(String[] args) {
		
//		int i = 5; // primitive data type
//		Integer j  = new Integer(5); // wrapper class
//		
//		int k =  j.intValue(); //unboxing
//		
//		Integer s = new Integer(i); // boxing
//		
//		
//		Integer m = i ; // autoboxing
//		
//		int p = j;
		
		
		int i  = 5 ;//primitive data type 
				
	  Integer j = new Integer(5);
		
	  int k = j.intValue(); // unboxing
	  Integer l = new Integer(i);  //boxing
	  
	  
	  
	  Integer m = i ; //autoboxing
	  int p = l; // autoboxing;
	  
	  
		
		
		
		
		
		
		
//		int a = 9474;
//		int sum = 0;
//		int b = a;
//		int digit = 0;
//		while(b != 0){
//			digit++;
//		b = b/10;
//		
//		
//		}
//		System.out.println(digit);
//		while(a > 0){
//		int x = a%10;
//		sum += Math.pow(x,digit);
//		a = a/10;
//		}
//		System.out.println(sum);
//		if(sum == 8208) System.out.println("YES");
//		 else System.out.println("NO");
		
		
		
		
		
	}
}
