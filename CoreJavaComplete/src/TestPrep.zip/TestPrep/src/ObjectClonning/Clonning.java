package ObjectClonning;

// Marker Interface Cloneable for permission or for security
class Ahu implements Cloneable {
	
	int i,j;

	@Override
	public String toString() {
		return "Ahu [i=" + i + ", j=" + j + "]";
	}
	

	public Object clone() throws CloneNotSupportedException 
	{
		return super.clone();
	}
	
	
	
	
	
}



public class Clonning {
	public static void main(String[] args) throws CloneNotSupportedException {
		/*
		 * Clonning 3 types: 1 Deep copy
		 *                  :2 Shallow Copy
		 *                  :3 clonning
		 */
		
		
		Ahu obj = new Ahu();
		obj.i=10;
		obj.j=20;
		
		Ahu obj1 = new Ahu(); // Deep copy
		obj1.i = obj.i;
		obj1.j= obj.j;
		
		System.out.println(obj1);
		
		Ahu obj2 = obj; //shallow copy //
		System.out.println(obj2);
		 
		Ahu obj3 = (Ahu)obj.clone();                     // Combination of both
		
		 System.out.println(obj3);
		 
		 
		 
			
			String s1 = "abc";
			String s2 = "abc";
			System.out.println("s1==s2" + "abc"=="abc");
			
			
			
			
			
			
			System.out.println(s1.equals(s2));
		
	}
	
}








// marker interface for permission
//class Abc implements Cloneable 
//{
//	int i ; 
//	int j ;
//	
//	
//	@Override
//	public String toString() {
//		return "Abc [i=" + i + ", j=" + j + "]";
//	}
//
//
//	@Override
//	public Object clone() throws CloneNotSupportedException
//	{
//		return super.clone();
//	}
//
//	
//}
//public class Clonning {
//public static void main(String[] args) throws CloneNotSupportedException {
//	
//	Abc obj = new Abc();
//	obj.i= 10;
//	obj.j=20;
//	
//	System.out.println(obj);
//	Abc obj1 = obj; // Shallow copy only reference is created.
//	
//	System.out.println(obj1);
//	
//	Abc obj2 = new Abc(); // Deep Copy
//	obj2.i = obj.i;
//	obj2.j=obj.j;
//	
//	System.out.println(obj2);
//	
//	Abc obj3 =(Abc)obj.clone();
//	
//	System.out.println(obj3);
//	
//}
//}
