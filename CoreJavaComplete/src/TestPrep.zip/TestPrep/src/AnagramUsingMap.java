import java.util.LinkedHashMap;
import java.util.Map;

public class AnagramUsingMap {

	public static boolean isAnagram(String str, String word)
	{
		str = str.toLowerCase();
		word = word.toLowerCase();
		
		
		char[] str1 = str.toCharArray();
		
		Map<Character, Integer>  m1 = new LinkedHashMap<Character, Integer>();
		for(int i =0;i<str1.length; i++)
		{
		
			if(m1.containsKey(str1[i]))
		{
			m1.put(str1[i], m1.get(str1[i])+1);
		}
		
			else {
				m1.put(str1[i], 1);
				
			}
			
		}
		
		for(int i =0; i<word.length();i++)
		{
		
			if(m1.containsKey(word.charAt(i)))
			{
				m1.put(word.charAt(i), m1.get(word.charAt(i))-1);
				
				if(m1.get(word.charAt(i))==0)
				{
					m1.remove(word.charAt(i));
				}
			}
			else {
				return false;
			}
			
			
		}
		
		return true;

	}
	
	public static void main(String[] args) {
		String str = "Marroy";
		String word= "Arormy";
		
	System.out.println(isAnagram(str, word));
		
	}
	
}
