package FactoryDesignPattern;

public interface Shape {
	void draw();
}


// Object creation logic hide client 
