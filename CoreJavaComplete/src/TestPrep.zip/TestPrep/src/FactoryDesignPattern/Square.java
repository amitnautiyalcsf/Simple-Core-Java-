package FactoryDesignPattern;

public class Square implements Shape {

	@Override
	public void draw() {
		System.out.println("Drawing Square");
		
	}
	

}


//Car color modelNo
//maruti has a engine     //engine

/*
 * //Maruti Extends Car{ private Engine engine;
 * 
 * 
 * 
 * }
 */ 
