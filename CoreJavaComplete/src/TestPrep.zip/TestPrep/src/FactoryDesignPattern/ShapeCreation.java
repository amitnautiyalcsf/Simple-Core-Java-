package FactoryDesignPattern;

//Factory Class
class findShape {

	public Shape getShape(String shapetype)
	{
		if(shapetype.equalsIgnoreCase("Circle"))
		{
			return new Circle();
			
		}
		
		if(shapetype.equalsIgnoreCase("Square"))
		{
			return new Square();
			
		}
		
		if(shapetype.equalsIgnoreCase("Rectangle"))
		{
			return new Rectangle();
			
		}
		
		return null;
		
	}
	
	
	
}

//using factory class to get shape
public class ShapeCreation {
	public static void main(String[] args) {
		findShape obj = new findShape();
		Shape shape1 = obj.getShape("Circle");
		shape1.draw();
		
		
		Shape shape2 = obj.getShape("Square");
		shape2.draw();
		
		Shape shape3 = obj.getShape("Rectangle");
		shape3.draw();
		
	}
}
