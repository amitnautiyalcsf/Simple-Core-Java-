
class A{
	
	 public  void show(int i)
	{
		
		System.out.println("It is a show Method :" + i);
	}
}

class B extends A 
{

	public void show(int i)
	{
		System.out.println( "It is as show method of B class: " +i);
	}

}


public class CoreJavaQus {

	public static void main(String[] args) {
		
		A obj = new B();
		B obj1 = new B();
		
		obj.show(10);
		obj1.show(15);
		
	}
	
}
