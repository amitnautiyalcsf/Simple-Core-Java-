import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class TestMain {

	public static void main(String[] args) {
		ArrayList<String> arl= new ArrayList<>();
		arl.add("Ammy");
		arl.add("Sonu");
		arl.add("Konu");
		arl.add("Sonu");
		arl.add("Ammy");
		
		Set<String>s = new HashSet<>();
		
		
		for(String name : arl)
		{
			if(s.add(name)==false)
			System.out.println(name);
			
		}
		
		
		List<Integer>values= new ArrayList<>();
		values.add(87);
		values.add(97);
		values.add(34);
		values.add(92);
		
		
	
		Collections.sort(values);
		Collections.reverse(values);
		for(Integer i : values)
		{
			System.out.println(i);
			
		}
		
Map<Integer,String> m = new TreeMap<>(); // gives an output based on key sorting.
		
		
		m.put(2, "Ammy");
		m.put(3, "Manu");
		m.put(1, "Rohit");
		
		Set<Map.Entry<Integer, String>> valus= m.entrySet();
		
		for(Map.Entry<Integer, String> value: valus)
		{
			System.out.println(value.getKey());
			System.out.println(value.getValue());
		}
	}

}
