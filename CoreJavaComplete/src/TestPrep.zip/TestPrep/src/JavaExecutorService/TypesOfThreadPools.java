package JavaExecutorService;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/* Types of pool 
1.Fixed Thread Pool : Done
2.Cached Thread pool
3.Scheduled Thread Pool
4.Single Threaded Executor*/ 


/*2 Cached Thread Pool : Here we don't have a fixed no of Threads and we also don't have a queue which is holding 
 * the no of tasks which we are submitting instead the queue is replaced by 
 * synchronous queue(only space for a single item) So every time we submit a task the pool will hold that 
 * task in synchronous queue and it will search for any of the threads which are already created and free 
 * to execute that task if no such thread is available it will create a new thread and added to the pool and 
 * ask that thread to execute the task: it is also having an abilty to kill those threads which are ideal for 
 * more than 60 sec 
 * 
 * 
 * */ 

/*3 Scheduled Thread Pool:Here it is specifically for the kind of tasks that you want to schedule after a
 * certain delay : here the queue used is a delayed work queue (where task might not be in a sequential manner, it is 
 * placed there as when the task is needed to be executed)
 * 
 * There are three methods we can use in it 
 * service.schedule: one of Task should trigger after certain delay 
 * service.scheduleAtFixedRate: a task which should keep triggering after certain seconds 
 * service.scheduleAtFixedDelay: Run the task 10 sec after the previous instance has run
 * 
 *t1 = 10 sec
 *10sec 
 *t2 = 20 sec   
*/


/*4 Single Threaded Executor: It is almost same as that of Fixed thread pool the only diff is it is having only 
 * single thread (size of pool is 1)which is fetching all the task from Linked blocking queue and running it. Also it 
 * recreates thread of killed because of the task. This type of thread pool is used when we want to maintain the 
 * order of task execution i.e task 2 will only run once task 1 is executed and completed   
*/


class Task implements Runnable{
	int i;
	public Task(int i) {
		// TODO Auto-generated constructor stub
	this.i=i;
	}
	@Override
	public void run() {
		System.out.println("Thread Name : " + Thread.currentThread().getName() + "this is " +i);
		
	}
	
}

public class TypesOfThreadPools {
	public static void main(String[] args) {
		
//	Cached Thread pool: doesn't take any arguments
//	ExecutorService service = Executors.newCachedThreadPool();
	
		int corePoolSize = 10;
		ScheduledExecutorService service = Executors.newScheduledThreadPool(corePoolSize);
		
		
		ExecutorService service1 = Executors.newSingleThreadExecutor();
		
		
		
		
		
	for(int i =0; i<100; i++)
	{
	//	service.execute(new Task());
		
	//	service.schedule(new Task(), 10, TimeUnit.SECONDS);
	//	service.scheduleAtFixedRate(new Task(i), 10, 20, TimeUnit.SECONDS);
//		service.scheduleWithFixedDelay(new Task(), 15, 10, TimeUnit.SECONDS);
		
	}
	System.out.println("Thread Name : " +Thread.currentThread().getName());
	

}
}
