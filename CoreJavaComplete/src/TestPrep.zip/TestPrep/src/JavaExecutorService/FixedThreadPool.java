package JavaExecutorService;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// 1 java thread corresponds =  1 OS Thread
//ThreadPool : pools of thread = fixed no of threads

//Fixed Thread pool internally uses Linked blocking queue in that queue it stores all the tasks which we have 
//submitted and all the 10 thread is performing two steps : fetch the next task from queue and execute it
//in order to perform the concurrent operations we are using thread safe queue (i.e Blocking queue)

// What is the ideal pool size ?
//ans : it depends the on the type of task we want to execute
//: CPU intensive operations like :task is using an alogrithm to create a hash or cryptographic functions: in this 
//  ideal size is having same no of threads = no of cores in the cpu

//: IO Intensive Task/Operations: Task is to get somedata from a DB or task is calling HTTP url and gets the data from there.
//In this case size of pool should be must higher in count so that all threads should not be in waiting state 





//class Task implements Runnable
class CpuIntensiveTasks implements Runnable
{

	@Override
	public void run() {
		System.out.println("Thread Name : " + Thread.currentThread().getName());
		
	}
	
	
}

public class FixedThreadPool {

	public static void main(String[] args) {
//		int nThreads=10;
//		ExecutorService service = Executors.newFixedThreadPool(nThreads);
		
		int coreCount = Runtime.getRuntime().availableProcessors();
		System.out.println(coreCount);
		ExecutorService service = Executors.newFixedThreadPool(coreCount);
		
		
		for(int i =0; i<100; i++)
		{
			//service.execute(new Task());
			service.execute(new CpuIntensiveTasks());
			
		}
		System.out.println("Thread Name : " +Thread.currentThread().getName());
		
		
	}
	


}

//completable future : asy perform(non- blocking) computational and triger dependent task

//ExecutorService Io intensive= Executors.newFixed()
//
//ExecutorService Cpuintensive= Executors.newFixed()
//
//
//
//completablefuture.supplyAsync(()->getOrder(),ioEtensive)
//.thenApply(order->enrich(order),)
//.thenApply(order->PerformPayment(order))
//.thenApply(order->disptach(order))
//.thenAccept(order->SendEmail(order));



//order place 
//order enrich
//order payment 
//order dispatch
//sendemail

//order place 
//order enrich
//order payment 
//order dispatch
//sendemail


//order place 
//order enrich
//order payment 
//order dispatch
//sendemail





//order place 
//order enrich
//order payment 
//order dispatch
//sendemail
