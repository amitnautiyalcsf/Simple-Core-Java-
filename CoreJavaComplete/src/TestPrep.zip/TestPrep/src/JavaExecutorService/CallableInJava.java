package JavaExecutorService;

import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

//class Task implements Runnable
class Task1 implements Callable<Integer>
{

	@Override
	public Integer call() throws Exception {
		Thread.sleep(5000);
		return new Random().nextInt();
	}
	
}


public class CallableInJava {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
	
		ExecutorService service = Executors.newFixedThreadPool(10);
		
		//submit the task for execution
		Future<Integer> future = service.submit(new Task1()); // Future is the placeholder for the value which 
		                                                     // will arrive sometime in the future 
		System.out.println(future.get());
		//perform Some unlrealted operations 
		if(true)
		{
			System.out.println(5+5);
		}
		
		try {
			Integer result = future.get(); // it is blocking opertions : blocks the main method until the future is ready 
                                           //  to return a value 
			System.out.println(result);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // it is blocking opertions : blocks the main method until the future is ready 
		                               //  to return a value 
		
		System.out.println("Thread Name :  " +Thread.currentThread().getName());
		
	}

	// AtomicInteger a =1 ;
	//  volatile boolean flag = true;
	// int a= 1;
	// t1
	//flag = false;
	
	// a.incement();
	
	
//t2
//	while(flag==true)
//	{
//		
//		
//	}
//	
//	sysout(a)
	
	
	
	
}
