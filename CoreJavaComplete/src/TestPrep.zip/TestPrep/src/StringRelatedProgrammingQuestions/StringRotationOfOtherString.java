package StringRelatedProgrammingQuestions;

//IndiaVsEngland
//EnglandIndiaVS rotated String : true 
//EnglandVSIndia Non roatetd: False


public class StringRotationOfOtherString {

	
	public static boolean isRotation(String original, String rotation)
	{
		
		if (original.length() != rotation.length()) 
		{ 
			return false; 
		
		}


	
		
		String concatenated = original + original;
		
		//int index = s3.indexOf(s2);
		
		int index = concatenated.indexOf(rotation);
		
		
		if (concatenated.contains(rotation)) 
		{
			return true; 
			
		}

		return false;
	}
	
	public static void main(String[] args) {
		String s1 = "IndiaVsEngland";
		String s2 ="EnglandVsIndia";
		
	System.out.println(isRotation(s1, s2));
	}
	
	
}
