package StringRelatedProgrammingQuestions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class zeroAtTheBegining {
public static void main(String[] args) {
	int arr[]= {0,1,1,0,1,0,1,0};
	int count =0;
	
	List<Integer> values = Arrays.asList(1,6,5,4,9,8,10,12);
	
	
	for(int i =0; i<arr.length;i++)
	{
		if(arr[i]==0)
		{
			
			arr[count]=0;
			count++;
		}
		else
		{
			continue;
		}
	}
	for(int j=count+1; j<arr.length;j++)
	{
		arr[j]=1;
		
	}
	
	for(int x: arr)
	{
		System.out.println(x);
	}
	
//	values.stream().filter(i->i%2==0).forEach(i->System.out.println(i));
	
List<Integer>al2 = new ArrayList<Integer>();	
	
al2 =values.stream().filter(i->i%2==0).collect(Collectors.toList()); 


	
}
}