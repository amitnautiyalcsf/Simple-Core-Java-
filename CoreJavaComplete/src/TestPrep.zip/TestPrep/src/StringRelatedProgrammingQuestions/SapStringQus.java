package StringRelatedProgrammingQuestions;

public class SapStringQus {

	public static void main(String[] args) {
		String str = "Hai i am SAP";
		
		//output = "iaH i ma PAS"
		String[] str1 = str.split(" ");
		
		for(int i= 0;i<str1.length; i++)
		{
			
			str1[i]= new StringBuilder(str1[i]).reverse().toString();
			
		}
		
		for(String x: str1)
		{
			
			System.out.print(x+" ");
		}
		
			
				
		
				
	}
}
