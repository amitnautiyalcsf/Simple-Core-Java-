package StringRelatedProgrammingQuestions;

public class PrintPalindromesOfString {

	public static void main(String[] args) {
		String str = "abcdaabaacdc";
		
		for(int i =0;i <str.length();i++)
		{
			
			for(int j =i+1; j<=str.length();j++)
			{
				String input = str.substring(i,j);
			//	System.out.println(input);
				
				boolean flag = checkifPalidrome(input);
				
				if(flag==true)
				{
					System.out.println(input);
					
				}
				
				
			}
				
		}
		
		
	}
	
	public static boolean checkifPalidrome(String input)
	{
		if(input.length()<2)
		{

			return false;
	  }
		else {
			
			String st = new StringBuilder(input).reverse().toString();
			
			if(st.equals(input))
			{
				return true;
			}
			
			}
		
		return false;
		}
}
