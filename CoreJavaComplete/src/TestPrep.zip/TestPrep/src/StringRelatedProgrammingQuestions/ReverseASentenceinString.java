package StringRelatedProgrammingQuestions;

import java.util.Arrays;
import java.util.List;

public class ReverseASentenceinString {
	
	public static String reverse(String str)
	{
		
		String[] arr = str.trim().split("\\s");
		String test="";
		
		for(int i = arr.length-1; i>=0;i--)
		{
			
			test = test+arr[i];
			test = test+ " ";
			
			
		}
		
		return test;
		
	}
	
	
	public static void main(String[] args) {
		String str = "Java is a Great Language";
		System.out.println(reverse(str));
		
	}

}
