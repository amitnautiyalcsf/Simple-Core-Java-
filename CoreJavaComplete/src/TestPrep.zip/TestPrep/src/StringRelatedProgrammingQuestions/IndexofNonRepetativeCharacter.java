package StringRelatedProgrammingQuestions;

import java.util.LinkedHashMap;
import java.util.Map;

public class IndexofNonRepetativeCharacter {
	
	
	public static void findIndex(String str)
	{
		String str1= str.toLowerCase();
		char data='o';
		Map<Character, Integer> m1 = new LinkedHashMap<Character, Integer>();
		int count =0;
	 for(int i =0;i<str1.length();i++)
	 {
		 if(m1.containsKey(str1.charAt(i)))
		 {
			 m1.put(str1.charAt(i), m1.get(str1.charAt(i))+1);
			 
			 
		 }
		 else {
			 m1.put(str1.charAt(i), 1);
			 
		 }
		 
	 }
	 
	
	 
	 for(Map.Entry<Character, Integer> x: m1.entrySet())
	 {
		 System.out.println(x.getValue() + " " + x.getKey() );
	if(x.getValue()==1)
	{
		data = x.getKey();
	}
		 
		 
	}
	 
	 for(int i =0;i <str1.length();i++)
	 {

		 if(str1.charAt(i)==data)
		 {
			 System.out.println(i);
		 }
	 
	}
}
	public static void main(String[] args) {
		findIndex("MararoyoM");
		
		
		
		
		
	}
	

}
