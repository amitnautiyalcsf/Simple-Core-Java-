package StringRelatedProgrammingQuestions;

import java.util.LinkedHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class firstNonRepetativeCharacterThroughStream {

	public static void main(String[] args) {
		String str = "Swiss Bank";
		
		String str1 = str.replace(" ", "");
		System.out.println(str1);
	//	String [] str1 = str.split("\\S");
				
		Character ch = str1.chars()
				.mapToObj(i->Character.toLowerCase(Character.valueOf((char)i)))
				.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
				.entrySet().stream()
				.filter(entry->entry.getValue()==1)
				.map(entry->entry.getKey()).skip(1)
				.findFirst().get();
		
		System.out.println(ch);
		
	}
	
	
}
