package StringRelatedProgrammingQuestions;

public class AnagramTest {

	
	public static boolean isAnagram(String str, String word)
	{
		
		int[] arr= new int[26];
		
		str= str.toLowerCase();
		word =word.toLowerCase();
		
		if(str.length()!= word.length())
		{
			return false;
		}
		
		for(int i=0;i<str.length();i++)
		{
			arr[str.charAt(i) -97] +=1;
		}
		
		for(int i =0;i<word.length();i++)
		{
			arr[word.charAt(i)-97] -=1;
		}
		
		for(int i =0;i<26; i++)
		{
			if(arr[i]<0)
			{
				return false;
			}
			
			
		}
		return true;
		
	}
	
	public static void main(String[] args) {
		String str= "Marry";
		String word= "Arrmy";
		
		System.out.println(isAnagram(str, word));
		
		
	}


}
