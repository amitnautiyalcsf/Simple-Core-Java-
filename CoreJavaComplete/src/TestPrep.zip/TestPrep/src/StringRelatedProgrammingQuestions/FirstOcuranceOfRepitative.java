package StringRelatedProgrammingQuestions;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

//swiss
public class FirstOcuranceOfRepitative {
 
	public static char firstFirst(String str)
	{
		Map<Character, Integer>m1 = new LinkedHashMap<Character,Integer>();
		
		Map<Character, Integer>resultMap = new LinkedHashMap<Character,Integer>();
		int count = 0;
		
		for(int i =0; i<str.length();i++)
		{
			
		//	m1.put(str.charAt(i), count);
			
			if(m1.containsKey(str.charAt(i)))
			{
				
				m1.put(str.charAt(i), m1.get(str.charAt(i))+1);
				
			}
			else {
				
				m1.put(str.charAt(i),1);
				
			}
			
			
			
		}
		
		for(Map.Entry<Character, Integer>m4: m1.entrySet())
		{
			
			System.out.println("Key :"+ m4.getKey()+ "Value " + m4.getValue() );
		}
		
		
		
		
	
	//	Iterator<Map.Entry<Character, Integer>> itr1= m1.entrySet().iterator();	
		
//		
//		for(Map.Entry<Character, Integer>m4: m1.entrySet())
//		{
//			
////		System.out.println("Key " + m4.getKey()+ " Value " +m4.getValue());
//			
//		for(int i=0;i<str.length();i++)
//		{
//			
//		char data = str.charAt(i);
//		
//		
//		if(m4.getKey()==data)
//		{
//			count = count+1;
//			resultMap.put(m4.getKey(),count);
//		}
//			
//		}
//		
//		count =0;
//		
//		}
//		
//		
//		for(Map.Entry<Character, Integer>m7 : resultMap.entrySet())
//		{
//			System.out.println("Key " + m7.getKey() + " Value " +m7.getValue());
//	
//		if(m7.getValue()==1)
//		{
//
//			return m7.getKey();
//			
//		
//		}
//		}
//		
		
		
		
//		m1.forEach((k,v) -> System.out.println("Key = "
//                + k + ", Value = " + v));
//		
//		Consumer<Integer> m2 = new Consumer<Integer>() {
//			
//			@Override
//			public void accept(Integer t) {
//				// TODO Auto-generated method stub
//				
//			}
//		};
//		
//		

	return 'o';
		
	}
	
	
	public static void main(String[] args) {
		
		char data = firstFirst("swiss");
		
		System.out.println(data);
		
		
		String a = "Amit";
		
		String b = new String("test");
		String c = new String ("test");
		String d = "test";
		System.out.println(a==d);
		System.out.println(b==c);
		System.out.println(a==b);
		
		System.out.println(b.equals(c));
		System.out.println(a.equals(b));
		
		System.out.println(a.equals(d));
		
		
		StringBuffer sb1 = new StringBuffer("Amit");
		StringBuffer sb2 = new StringBuffer("Amit");
		
		System.out.println(sb1==sb2);
		System.out.println(sb1.equals(sb2));
		System.out.println(sb1.equals(a));
		
		
}
	
}
