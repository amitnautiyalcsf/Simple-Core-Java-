package StringRelatedProgrammingQuestions;

public class NoOfTimesStringNeededTogetSubStrings {
	public static void main(String[] args) {

	String a= "adb";//"abcd";
	String b = "abc";//"cdabcdab";
	

	
	
	int n = a.length();
	int k = b.length();
	int p = n+k;
	int count =0;
	boolean flag = false;
	String sb = "";
	while(k<=p)
	{
		if(sb.contains(b))
		{
			flag = true;
			break;
		}
		
		else {
			
			sb = sb+ a;
			count ++;
		}
		
		k = sb.length();
		
	}
	
	if(flag == true)
	{
		System.out.println(count);
	}
	else {
		System.out.println("-1");
	}
		
		
		
	}

}

