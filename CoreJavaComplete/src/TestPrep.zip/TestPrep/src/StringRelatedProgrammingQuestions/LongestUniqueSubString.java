package StringRelatedProgrammingQuestions;

import java.util.HashMap;

public class LongestUniqueSubString {
	
	public static int longestUniqueSubString(String str)
	{
		HashMap<Character, Integer> m1 = new HashMap<>();
		int maxi= 0;
		int i =0;
		
		for(int j =0; j<str.length(); j++)
		{
			if(m1.containsKey(str.charAt(j)))
			{
				i = Math.max(i, m1.get(str.charAt(j))+1);
				
			}
			
			m1.put(str.charAt(j), j);
			maxi = Math.max(maxi, j-i+1);
		}
		
		return maxi;
		
	}
	
	public static void main(String[] args) {
		String str ="geeksforgeeks";
	System.out.println(longestUniqueSubString(str));
	}
	
}
