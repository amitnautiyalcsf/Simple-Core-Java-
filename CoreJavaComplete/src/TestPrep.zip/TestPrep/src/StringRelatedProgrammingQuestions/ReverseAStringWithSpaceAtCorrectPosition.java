package StringRelatedProgrammingQuestions;

public class ReverseAStringWithSpaceAtCorrectPosition {

	static void swap(char[] str, int i, int j)
	{
		  char temp = str[i];
	        str[i] = str[j];
	        str[j] = temp;
		
	}
	
	static String reverse(String str1)
	{
       
		char[] str = str1.toCharArray();
		int j = str1.length()-1;
		String sb ="";
		
		//StringBuffer sb = new StringBuffer();
		
		for(int i =0; i<str.length;i++)
		{
			
			if(str[i]==' ')
			{
				continue;
			}
			
			
			if(i<=j)
			{
				if(str[j]==' ')
				{
					j--;
				}
				swap(str,i,j);
				j--;
				
			}
			
			
		}
		
		
		for(int i =0;i <str.length; i++)
		{
			sb = sb+str[i];
		}
		
		
		return sb;
	}
	
	
	public static void main(String[] args) {
		
		String str = "my name is rohit";
		
		System.out.println(reverse(str));
		
		
	}
}
