package StringRelatedProgrammingQuestions;

public class PermutationOfStringMMT {

	public static void permutation(String inputString, String temp) {

		if (inputString.isEmpty()) {
			System.out.println(temp);
			return;
		}

		boolean arr[] = new boolean[26];

		for (int i = 0; i < inputString.length(); i++) {
			char ch = inputString.charAt(i);
			if (arr[ch - 'a'] == false) {
				permutation(inputString.substring(0, i) + inputString.substring(i + 1, inputString.length()),
						temp + ch);
			}
			arr[ch - 'a'] = true;

		}

	}

	public static void main(String[] args) {
		String str = "aab";
		permutation(str, "");
	}
}
