package StringRelatedProgrammingQuestions;

public class ZerosAtTheEnd {
	public static void main(String[] args) {
		
	
	int arr []= {5,0,3,0,6,9,0,2,1,0};
	int k =0;
	for(int i =0;i<arr.length;i++)
	{
		if(arr[i]==0)
		{
			continue;
		}
		
		else {
			arr[k]= arr[i];
			k++;
		}
		
	}
	

	for(int j=k+1; j<arr.length; j++)

	{
      
		arr[j]=0;	

	}
	
	for(int x: arr)
	{
		System.out.println(x);
	}

}
	
	
}
