package ReflectionApiPrivateMethodCalling;

public class Test {

	private void disp()
	{
		System.out.println("This is a private method");
	}
}
