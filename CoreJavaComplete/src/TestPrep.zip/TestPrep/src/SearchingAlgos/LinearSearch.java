package SearchingAlgos;

public class LinearSearch {
	
	
	
	public static int linearSearch(int key, int arr[])
	{
		for(int i = 0; i<arr.length;i ++)
		{
			if(arr[i]== key)
			{
				
				return i;
			}
			
		}
		return 0;
	}
	
	public static void main(String[] args) {
		int arr[] = {9,10,78,27,81,100,289};
		
		System.out.println(linearSearch(27, arr));
	}

}
