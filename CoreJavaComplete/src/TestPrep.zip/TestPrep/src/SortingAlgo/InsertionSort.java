package SortingAlgo;

//1   4  8   [5]   9  2

// 1  4 [5] [8]  9  2

// // 1  4 5 8  9  2

//  1  [] 4 5  8  9

// temp =2

// 1 2 4 5 8 9


// 6 4 8 9 [2] 7 1
//6 4 8 9 [ ] 7 1
// temp= arr[i]=2
//6 4 8 [2] 9 7 1 

// arr1= {2,3,7,5,9,11}
//arr2 = {7,6,5,3,8}
//Sum 14




public class InsertionSort {
	
	public static void insertSort(int arr[])
	{
		for(int i =1; i< arr.length; i++)
		{
			
			int temp = arr[i];
			int j = i-1;
			while(j>=0 && arr[j]>temp)
			{
				
				arr[j+1]= arr[j];
				j--;
				
			}
			
			
			arr[j+1]= temp;
			
			
		}
	
		
	}
	
	
	public static void main(String[] args) {
		int arr[] = {45,21,67,39,20,1,3,42,6};
		insertSort(arr);
		
		for(int x: arr)
		{
			System.out.println(x);
			
		}
		
		
		
		
	}
		
		
		
		
		
	}
		
		
//		for(int i = 1 ; i <arr.length; i++ )
//		{
//			int temp = arr[i];
//			int j = i-1;
//			
//			while(j>=0 && arr[j]> temp)
//			{
//			
//				arr[j+1]= arr[j];
//				j--;
//				
//			}
//			
//			arr[j+1]= temp;
//		}
//		
//		
//	}
//	
//	
//	
//	
//	public static void main(String[] args) {
//		int arr[] = {67,39,20,100,29,9};
//		
//		insertSort(arr);
//		
//		for(int x: arr)
//		{
//			
//			System.out.println(x);
//		}
//		
//	}
	
	
	
//}
	
//	1 4 8 5 9 2
	
//	public static void insertSort(int arr[])
//	{
//		for(int i=1;i<arr.length; i++)
//		{
//			int element = arr[i];
//			int j = i-1;
//			while(j>=0 && arr[j]> element)
//			{
//				arr[j+1]= arr[j];
//				j--;
//				
//			}
//			arr[j+1]= element;
//		}
//		
//	}
	
//	public static void main(String[] args) {
//		int arr[] = {16,28,18,11,9,28,34,76};
//		insertSort(arr);
//		
//		for(int i =0; i <arr.length; i++)
//		{
//			
//			System.out.println(arr[i]);
//		}
//		
//	}
//
//}
