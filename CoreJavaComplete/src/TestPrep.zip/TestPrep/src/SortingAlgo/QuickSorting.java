package SortingAlgo;

//5,8,2,38,9,10
//5 2 8 38 9 10
//2 5 8 38 9 10
public class QuickSorting {

//	public void quickSort(int arr[], int l, int h)
//	{
//		if(l<h)
//		{
//		int p = partition(arr,l,h);
//		
//		quickSort(arr,l,p-1);
//		quickSort(arr,p+1,h);
//		}
//	}
//	
//	
//	
//	public int partition(int arr[], int l, int h)
//	{
//			int pivot = arr[l];
//			int j = h;
//			int i =l;
//		while(i<j)
//		{
//			while(arr[i]<=pivot && i<h-1)
//			{
//				i++;
//				
//			}
//			
//			while(arr[j]>pivot && j>=l)
//			{
//				
//				j--;
//			}
//					
//			if(i<j)
//			{
//				swap(arr,i,j);
//			}
//			
//		}
//		swap(arr,j,l);
//		return j;
//	
//		
//	}
//	
//	public static void swap(int arr[], int first, int second)
//	{
//		
//		int temp  = arr[first];
//		arr[first]= arr[second];
//		arr[second]= temp;
//		
//	}
//	
//	
//	
//	
//	public static void main(String[] args) {
//		int arr [] = {56,29,19,39,10,22,11,4,21,77};
//		QuickSorting obj = new QuickSorting();
//		obj.quickSort(arr, 0, arr.length-1);
//		
//		for(int x: arr)
//		{
//			System.out.println(x);
//			
//		}
//	}
	
	
	public static void quickSort(int arr[], int l, int h)
	{

		if(l<h)
		{
		int p = partition(arr, l, h);
		quickSort(arr, l,p-1);
		quickSort(arr, p+1 , h);
		}
		
		
	}
	
	public static int partition(int arr[], int l, int h)
	{
		int pivot = arr[l];
		int i = l;
		int j =h;
		
		while (i<h)
		{
			
			while (arr[i]<=pivot && i<=h-1)
			{
				i++;
			}
			
			while(arr[j]>pivot && j>=l)
			{
				j--;
				
			}
			if(i<j)
			{
				swap(arr, i ,j);
				
			}
		}
		swap(arr , j ,l);
		return j;
	}
	
	public static void swap(int arr[], int first, int second)
	{
		
		int temp  = arr[first];
		arr[first]= arr[second];
		arr[second]= temp;
		
	}
	
	public static void main(String[] args) {
		
		int arr1[]= {9,98,39,10,199,28,989,26,18};
		
		int arr[]= {77,5,6,3,4,2};
		
		
		QuickSorting.quickSort(arr, 0, arr.length-1);
		
		for(int i = 0 ; i<arr.length;i ++)
		{
			System.out.println(arr[i]);
		}
	}
}
