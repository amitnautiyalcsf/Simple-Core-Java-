package SortingAlgo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Stack;

public class SortAnelementsInStackRecursion {

	public static void sortStack(Stack<Integer>s )
	{
		
		if(!s.isEmpty())
		{
			int x = s.pop();
			sortStack(s);
		SortedStackInsert(s, x);	
			
		}
		
	}
	
	public static void SortedStackInsert(Stack<Integer>s , int x)
	{
		
		if(s.isEmpty()|| x>s.peek())
		{
			
			s.push(x);
			return;
		}
		
		int temp = s.pop();
		SortedStackInsert(s, x);
		s.push(temp);
		
	}
	
	public static void display(Stack<Integer>s)
	{
		
		ListIterator<Integer>it = s.listIterator();
		
		while(it.hasNext())
			it.next();
		
		while(it.hasPrevious())
		{
			System.out.println(it.previous());
		}
	}
	 
	public static void main(String[] args) {
		Stack<Integer>s = new Stack<>();
		 s.push(30);
	        s.push(-5);
	        s.push(18);
	        s.push(14);
	        s.push(-3);
		
		
		System.out.println("Before Sorting");
		
		display(s);
		
		System.out.println("After Sorting");
		
		sortStack(s);
		
		display(s);
		
		
		List<? extends Number> al = new ArrayList<Integer>();
	
		
		String str = "I am a Java developer";
		
		String[] str1 = str.substring(beginIndex)
	
		
		
		
	}
	
}
