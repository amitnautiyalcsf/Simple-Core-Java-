package SortingAlgo;


//Two Major Steps
//1.Splitting
//2.Merging

//5 7 3 2     9 4 2 1
//
//4,6,2,63   8,1,3,9

public class MergeSorting //O(nlogn)
{

	public void mergeSort(int inputArray[],int start, int end )
	{
		
		if(start<end)
		{
			int mid = (start+end)/2;
			mergeSort(inputArray,start, mid);
			mergeSort(inputArray,mid+1, end);
			merge(inputArray,start,mid,end);
			
		}
		
	}
	
	
	public void merge(int inputArray[], int start, int mid, int end)
	{
		
		int tempArray[] = new int[end-start+1];
		int leftslot= start;
		int rightslot= mid+1;
		int k =0;
		
		while(leftslot<=mid && rightslot<=end)
		{
			
			if(inputArray[leftslot]< inputArray[rightslot])
			{
				tempArray[k]= inputArray[leftslot];
				leftslot++;
				
			}
			
			else
			{
				
				tempArray[k] = inputArray[rightslot];
				rightslot++;
			}
			k++;
			
		}
		
		if(leftslot<=mid)
		{
			
			while(leftslot<=mid)
			{
				tempArray[k] = inputArray[leftslot];
				leftslot++;
				k++;
			}
			
		}
		
		else if(rightslot<=end)
		{
			
			while(rightslot<=end)
			{
				
				tempArray[k] = inputArray[rightslot];
				rightslot++;
				k++;
			}
		}
		
		for(int i=0 ;i<tempArray.length; i++)
		{
			
			inputArray[start +i]= tempArray[i];
			
		}
		
		
	}
	
	public static void main(String[] args) {
		
		int inputArray[] = {36,39,20,3,49,78};
		MergeSorting obj = new MergeSorting();
		obj.mergeSort(inputArray, 0, inputArray.length-1);
		
		for(int x: inputArray)
		{
			
			System.out.println(x);
		}
	}
}















//public class MergeSorting //O(nlogn)
//{
//	public static void main(String[] args) 
//	{
//	  int inputArray[] = {12,81,74,43,1093,8,92,17,754,912,6,4};
//	    mergeSort(inputArray,0,inputArray.length-1);
//	  for(int i=0;i<inputArray.length;i++)
//	  {
//	  System.out.println(inputArray[i]);    
//	  }
//	}
//	public static void mergeSort(int inputArray[],int start, int end)
//  {
//     
//   if(start<end) {
//      int mid= (start+end)/2;
//      mergeSort(inputArray,start,mid);// sort left half
//      mergeSort(inputArray,mid+1,end);// sort right half
//      merge(inputArray,start,mid,end);// merge sorted results into the input array
//  }
//  }
//      
//  
//  
//  public static void merge(int inputArray[],int start, int mid, int end)
//  {
//      int tempArray[]= new int[end-start+1];
//      int leftslot=start;// index counter for the left side of the array.
//      int rightslot=mid+1;//index counter for the right side of the array.
//      int k =0;
//      while(leftslot<=mid && rightslot<=end)
//      {
//          if(inputArray[leftslot]<inputArray[rightslot])
//          {
//              tempArray[k]=inputArray[leftslot];
//              leftslot=leftslot+1;
//          }
//          else
//          {
//              tempArray[k]=inputArray[rightslot];
//              rightslot=rightslot+1;
//              
//          }
//          
//          
//         k++;  
//      }
//     
//      // When it gets to here that meansthe above loop has completed. so either the rightside or the leftSide of the subarray has been sorted.
//
//     if(leftslot<=mid)// right side has been sorted.
//     {
//         while(leftslot<=mid)// Now we can just copy over the rightside elemens.
//         {
//             tempArray[k]=inputArray[leftslot];
//             leftslot++;
//             k++;
//             
//         }
//     }
//         else if(rightslot<=end)// left side has been sorted right is still remaining.
//         {
//             while(rightslot<=end)
//             {
//                 tempArray[k]=inputArray[rightslot];
//                 rightslot++;
//                 k++;
//                 
//             }
//             
//         }
//         
//         //copy over the tempArray into the appropriate slots of the inputArray for further processing.
//         for(int i=0; i<tempArray.length;i++)
//         {
//             inputArray[start+i]=tempArray[i];
//             
//         }
//         
//     }
//}