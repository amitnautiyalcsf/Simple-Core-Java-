package SortingAlgo;

public class BubbleSort {
	
	// 8,5,2,6,1,9
	//5 8 2 6 1 9
	// 2 8 5 6 1 9 
	//1 8 5 6 2 9
	
	
	public static void sort(int arr[])
	{
		boolean swapped= false;
		
		for(int i =0; i <arr.length; i++)
		{
			for(int j = i+1; j <arr.length; j++)
			{
				if(arr[j]<arr[i])
				{
					int temp = arr[j];
					arr[j]= arr[i];
					arr[i]= temp;
					swapped = true;
				}
				
			}
			
			if(swapped ==false)
			{

				break;
			}
			
		}
	}
	
	public static void main(String[] args) {
		int arr[] = {560,23,2291,329,430,320000,12,1,6};
		sort(arr);
		for(int x: arr)
		{
			System.out.println(x);
		}
	}
}
