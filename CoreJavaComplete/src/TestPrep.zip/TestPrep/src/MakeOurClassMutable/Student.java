package MakeOurClassMutable;

import java.util.ArrayList;
import java.util.Collections;

//1 FINAL CLASS  --- NO EXTEND
//2 SETTERS - NO --  CAN SET VALUES DIRECTLY 
//3 PRIVATE FINAL VARIBALES -- CAN ACT AS A CONSTANT THROUGHOUT 
//4 VARIABLES SHOULD BE SET THROGHU CONS


public final class Student {
	
	private final int id;
	private final String name;
	private final Age age;
	private final ArrayList<Integer> al = new ArrayList<>();
	
	
	
	
	public Student(int id, String name, Age age) {
		this.id= id;
		this.name= name;
		
		Age cloneAge = new Age();
		cloneAge.setDay(age.getDay());
		cloneAge.setMonth(age.getMonth());
		cloneAge.setYear(age.getYear());
		this.age= cloneAge;
	}

	public ArrayList<Integer> getAl() {
		Collections.unmodifiableList(al);
		return al;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Age getAge() {
		
		Age cloneAge= new Age();
		cloneAge.setDay(this.age.getDay());
		cloneAge.setMonth(this.age.getMonth());
		cloneAge.setYear(this.age.getYear());
		return cloneAge;
	}
	
	
	public static void main(String[] args) {
		
		Age age = new Age();
		age.setMonth(9);
		age.setDay(18);
		age.setYear(1995);
				
		Student obj = new Student(101, "Rohit", age);
		
		System.out.println("Birth year of Rohit is " + obj.getAge().getYear());
		
		obj.getAge().setYear(1996);
		
		System.out.println("Birth year of Rohit is " + obj.getAge().getYear());
		System.out.println(obj.getAge());
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

//	private final int id;
//    private final String name;
//    private final Age age;
//    
//    public Student(int id, String name, Age age) {
//    	this.name = name;
//        this.id = id;
//        Age cloneAge = new Age();
//        cloneAge.setDay(age.getDay());
//        cloneAge.setMonth(age.getMonth());
//        cloneAge.setYear(age.getYear());
//        this.age = cloneAge;
//	}
//
//	public int getId() {
//		return id;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public Age getAge() {
//		Age cloneAge= new Age();
//		cloneAge.setDay(this.age.getDay());
//		cloneAge.setMonth(this.age.getMonth());
//		cloneAge.setYear(this.age.getYear());
//		return cloneAge;
//	}
//    
//    public static void main(String[] args) {
//		
//    	Age age = new Age();
//    	age.setDay(24);
//    	age.setMonth(9);
//    	age.setYear(1995);
//    	
//    	Student st = new Student(101, "Amit", age);
//    	System.out.println("Birth Year of Amit is: " + st.getAge().getYear());
//    
//    	st.getAge().setYear(1994);
//
//    	System.out.println("Birth Year of Amit is: " + st.getAge().getYear());
//    	
//	}
//	
	
	
}
