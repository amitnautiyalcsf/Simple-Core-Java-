
public class ReverseAStringinPlace {

	public static String reverse(String str)
	{
		char[] temp= str.toCharArray();
		
		if(str.length()==0 && str.isEmpty())
		{
			System.out.println("String is empty");
		}
		
		int i = 0;
		int j = temp.length-1;
		while(i<j)
		{
			char result = temp[i];
			temp[i]= temp[j];
			temp[j]=result;
			i++;
			j--;
		}
		String result ="";
		for(char x: temp)
		{
		  result += x;
		}
		
		
		System.out.println(result);
	
		return result;
	
	}
	
	
	public static void main(String[] args) {
		String str = "AmmyNautiyal";
		reverse(str);
		
	
	}
}
