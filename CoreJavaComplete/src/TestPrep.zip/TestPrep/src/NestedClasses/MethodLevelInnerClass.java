package NestedClasses;

class Ioi{
	
	private int i = 10;
	static int j =20;
	int k =90;
	
	public void show()
	{
		
		class Tuy{
			
			public void disp()
			{
				
				System.out.println("This is a method Level Inner classe");
				System.out.println(i);
				System.out.println(j);
				System.out.println(k);
			}
			
		}
		
		Tuy obj = new Tuy();
		obj.disp();
		
		
	}
	
}
public class MethodLevelInnerClass {
public static void main(String[] args) {
	
 Ioi obj1 = new Ioi();
 obj1.show();
	
}
}
