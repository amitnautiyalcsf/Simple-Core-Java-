package NestedClasses;


class Uio{
	int i = 10;
	private int j =20;
	static int k =40;
	private static int l=50;
	class Olo{
		
		public void display()
		{
			System.out.println("It is local Inner class");
			System.out.println(i);
			System.out.println(j);
			System.out.println(k);
			System.out.println(l);
			
			
		}
		
		
	}
	
}


public class LocalInnerClass {
	public static void main(String[] args) {
		Uio obj = new Uio();
		Uio.Olo obj2 = obj.new Olo();
		
		obj2.display();
		
	}

}
