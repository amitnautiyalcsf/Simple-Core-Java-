package NestedClasses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/*Nested Classes

1 Static Inner class: Done
2 Non static Inner class
a Local InnerClass: Done
b method level innerclass: Done 
c anonymous class  :: Done */
         

//1. Static Inner Class
 
class Aol{
	
    static int i = 10;
	private static int j = 20;
	int k = 30;
 static class Lol{
		
	public void show()
	{
		System.out.println("This is static inner class method");
		System.out.println(i);
		System.out.println(j);
		//System.out.println(k);
		
	}
		
	}
	
	
}


//35->7->4->0->9->null
//


public class StaticinnerClass {
public static void main(String[] args) {
	Aol.Lol obj2 = new Aol.Lol();
	obj2.show();
	
	
	
	Map<String, String>m1 = new ConcurrentHashMap<>();
	
	List<Integer> al = new CopyOnWriteArrayList<Integer>();
	
	
	al.add(1);
	al.add(2);
	
	for(Integer x: al)
	{
		
	 al.add(3);
		
	}
	
	
	m1.put("Nokia", "3315");
	m1.put("Samsung", "s02");
	
	for(Map.Entry<String, String>entry: m1.entrySet())
	{		
		System.out.println(entry.getKey() + "" + entry.getValue());
		m1.put("oneplus", "5t");
	}
	
	System.out.println(" ");
	
	for(Map.Entry<String, String>entry: m1.entrySet())
	{		
		System.out.println(entry.getKey() + "" + entry.getValue());
	}
	
	
	
	
	
	
	
	
}	
	
}
