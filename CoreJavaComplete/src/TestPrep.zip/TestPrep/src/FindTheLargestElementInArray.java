
public class FindTheLargestElementInArray {
	
	public static void main(String[] args) {
		int arr[] = {5,39,2,19,40,30,999,2,3,6};
		
		int first =  Integer.MIN_VALUE;
		int second =first;
		
		for(int i =0;i<arr.length;i++)
		{
			if(arr[i]>first)
			{

				second = first;
				first = arr[i];
			}
			
			else if(arr[i]>second && arr[i]!=first)
			{
				second = arr[i];
			}

		}
		
		if(second == Integer.MIN_VALUE)
		{
			System.out.println("Second largest doesn't exist");
		}
		else {
			
			System.out.println("Second largest element is " +second);
		}
		
	}
	

}
