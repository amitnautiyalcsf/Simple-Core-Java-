package Java8Fearures;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

class Employee{
	
	private int empId;
	private String empName;
	private String designation;
	
	
	public Employee( int empId, String empName, String designation) {
		// TODO Auto-generated constructor stub
		this.empId= empId;
		this.empName=empName;
		this.designation=designation;
	}
	
	
	public void disp()
	{
		
		System.out.println("Display");
	}
	
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}


	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", designation=" + designation + "]";
	}
	
	
	
	
}


public class GroupingByInJava {

	public static void main(String[] args) {
		
		Employee obj = new Employee(12, "Amit","SeniorSoftwareEngineer");
		Employee obj1 = new Employee(45, "Rohit", "SeniorSoftwareEngineer");
		Employee obj2= new Employee(98, "Manu", "AssociateITConsultant");
		Employee obj3 = new Employee(22, "Ankit", "SoftwareEngineer");
		
		List<Employee>al =  Arrays.asList(obj,obj1,obj2,obj3);
	////////////////////////////////////////////////////////////////////////////	
		Optional<Employee> emp = al.stream()
		        .sorted(Comparator.comparingInt(Employee::getEmpId)
		        		.reversed()).skip(1).findFirst();
	///////////////////////////////////////////////////////////////////////////	
		
     String str = "Swwiiss BBaannkk";
	String str1 = str.replace(" ", "");
		System.out.println(str1);
	
		Character ch = str1.chars()
				.mapToObj(i->Character.toLowerCase(Character.valueOf((char)i)))
				.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
				.entrySet().stream()
				.filter(entry->entry.getValue()==1)
				.map(entry->entry.getKey())
				.findFirst().get();
		
		System.out.println(ch);
		
	/////////////////////////////////////////////////////////////////////////////////	
		Map<String, Map<Integer, List<Employee>>> m1 = al.stream()
				.collect(Collectors.groupingBy(Employee::getDesignation, 
						Collectors.groupingBy(Employee:: getEmpId)));
	////////////////////////////////////////////////////////////////////////////////	
		
		Optional<Employee> o1 = al.stream()
				.sorted(Comparator.comparingInt(Employee::getEmpId)
				.reversed()).skip(1).findFirst();
	////////////////////////////////////////////////////////////////////////////////////////	
//		System.out.println(al2
//				  .stream()
//				  .flatMap(Collection::stream)
//				  .collect(Collectors.toList()));
	////////////////////////////////////////////////////////////////////////////////////////
		System.out.println(o1);
		
		

		Thread t1 = new Thread()
				{

			public void run()
			{
				Employee e1 = new Employee(2100, "amit", "SE");
				e1.disp();
			}
			
				};
				
				
			Thread t2 = new Thread()
				{

			public void run()
			{
				Employee e2 = new Employee(2100, "amit", "SE");
				e2.disp();
			}
			
				};		
		
		

		System.out.println(emp.get());
		
		System.out.println("Group by on multiple properties and Map key as List" + m1);
		
	}
}
