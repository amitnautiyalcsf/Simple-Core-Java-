package Java8Fearures;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class StreamMapReduceMethod {

	public static void main(String[] args) {
		List <Integer> values = Arrays.asList(12,20,35,46,55,68,75);
	
		int result  =0 ;
		
//		for(Integer x : values)
//		{
//			
//			result = result+ x*2;
//			
//		}
//		System.out.println(result);
		
//		Function<Integer,Integer> f = new Function<Integer,Integer>() {
//
//			@Override
//			public Integer apply(Integer t) {
//				
//				return t*2 ;
//			}
//			
//			
//			
//		};
//		
//		
//		BinaryOperator<Integer> b = new BinaryOperator<Integer>() {
//
//			@Override
//			public Integer apply(Integer t, Integer u) {
//				// TODO Auto-generated method stub
//				return t+u;
//			}
//		};
//		
//		
//	    Stream s1 = values.stream();
//		
//	    Stream s2  = s1.map(f);
//		
//		 int result1  = (int) s2.reduce(0,b);
//	
//		 
//		 System.out.println(result1);
		           
//		   System.out.println( values.stream().map(i->i*2).reduce(0,(t,u)->t+u));   
//	
//		      
//		   System.out.println( values.stream().filter(i->i%5==0).reduce(0,(t,u)->t+u));
//		      
		   Stream s1= values.stream();
		   
		   Predicate<Integer> p = new Predicate<Integer>() {

			@Override
			public boolean test(Integer t) {
				// TODO Auto-generated method stub
				return t%5==0;
			}
			   
			 
			   
		   };
		   
		   
			BinaryOperator<Integer> b = new BinaryOperator<Integer>() {
		   
		   			@Override
		   			public Integer apply(Integer t, Integer u) {
		   				// TODO Auto-generated method stub
		   				return t+u;
		   			}
		   		};
		   
		   Stream s2  = s1.filter(p);
		   int result4 =  (int) s2.reduce(0,b);
		   
//		   System.out.println(result4);
//		   
//		   
//		   
//		   System.out.println(values.stream()
//                   .filter(i->i%5==0)
//                   .map(i->i*2)
//                   .findFirst()
//                   .orElse(0));
		   
		   
		   
		   
	
		   List<Integer>l1 = Arrays.asList(10,-29,39,19,-18,100,-12);
			
		   System.out.println(l1.stream().filter(i->(i<0).reduce(0,(t,0)->t+0));
		  
				
				Predicate<Integer> p2 = new Predicate<Integer>() {

					@Override
					public boolean test(Integer t) {
						// TODO Auto-generated method stub
						
						return t<0;
					}
					   
					 
					   
				   };
				   
				   
				  
				   
				   
				   Function<Integer,Integer>f = new  Function<Integer, Integer>() {

					@Override
					public Integer apply(Integer t) {
						// TODO Auto-generated method stub
						
						System.out.println(t);
						return t;
					}
					   
				};
				
				
				 System.out.println(l1.stream()
						   .filter(p2)
						   .map(f));
								   
				 
				 
	}
	
	
	
	BinaryOperator<Integer> b3 = new BinaryOperator<Integer>() {

		@Override
		public Integer apply(Integer t, Integer u) {
			// TODO Auto-generated method stub
			return t+0;
		}
	};
	
	
   
	
	
		   
		   
		   
		   

		   
		
	}
	
	
