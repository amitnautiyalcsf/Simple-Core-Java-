package Java8Fearures;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class InternalIteration {
	
	public static void main(String[] args) {
		
		
		List<Integer> values = Arrays.asList(1,2,3,5,8,4,2);
		
//		for(Integer x: values) /// External Iteration
//		{
//			System.out.println(x);
//			
//		}
		
	// Internal Iteration	
	// Consumer Interface// functional Interface
		
		
//		Consumer<Integer> values1 = new Consumer<Integer>() {
//
//			public void accept(Integer t) {
//				System.out.println(t);
//				
//			}
//		};
//		
//		values.forEach(values1);
		
		
		values.forEach(i->System.out.println(i)); // internal iteration
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
//	List<Integer> values = Arrays.asList(1,2,3,4,5,6);
	
	// Internal Iteration // Using consumer interface(Functional Interface)
	
//	Consumer<Integer> c = new Consumer<Integer>()
//			{
//		
//		
//		public void accept(Integer i)
//		{
//			System.out.println(i);
//			
//		}
//		
//	};
//	
//	values.forEach(c);
//	
//	
	

//	values.forEach(new Consumer<Integer>()
//			{
//
//
//		@Override
//		public void accept(Integer t) {
//
//			System.out.println(t);
//		}
//		
//			}
//		);
//	
	
//	values.forEach(i->System.out.println(i));
	
	
}
	
	
	
	
}
