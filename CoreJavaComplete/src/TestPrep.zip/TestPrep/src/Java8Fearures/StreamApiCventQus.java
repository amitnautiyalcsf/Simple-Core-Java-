package Java8Fearures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.lang.model.element.VariableElement;

public class StreamApiCventQus {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,2,3,4,5,6);
		
		Stream s1 = list.stream();
		
		Predicate<Integer>  p1 = new Predicate<Integer>() {
			
			@Override
			public boolean test(Integer t) {
				if(t%2==0)
				{
					return true;
				}
				return false;
			}
		};
		
Predicate<Integer>  p2 = new Predicate<Integer>() {
			
			@Override
			public boolean test(Integer t) {
				if(t%2==1)
				{
					return true;
				}
				return false;
			}
		};
		
		
	 s1.filter(p1)
				.collect(Collectors.toList());
		
	s1.filter(p2).collect(Collectors.toList());
		
				
		
	}
}
