package Java8Fearures;

// Normal interface : Can have multiple methods inside it.
// SAM Interface -- Single Abstract Method Interface -- Functional Interface -- It is having only one abstrat methods
// Marker Interface: It doesn't have any method inside it : Serializable , Clonnable

@FunctionalInterface
interface Olo
{

	void show();
//	void display(); // will give me an error bcoz it is a functional interface
	
	default void display()
	{
		
	System.out.println("This is display method");
		
	}
	
	static void test()
	{
		System.out.println("This is Test method");
	}

}


abstract class Tpo{
	
	public abstract void ioi();
	
}

interface iuo
{

	public void checking();
	
}


public class TypesOfInterfaaces {
	
	public static void main(String[] args) {
		
	Olo obj = ()->{
		System.out.println("This is a show method");
		
	};
	
	
iuo obj6 = new iuo() {
	
	public void checking()
	{
		
	}
	
};
	
	
	
	Runnable obj5 =()->{
		
		
	};
	
	
	
	obj.show();
	obj.display();
	Olo.test();

	
	
	
	

}
}
