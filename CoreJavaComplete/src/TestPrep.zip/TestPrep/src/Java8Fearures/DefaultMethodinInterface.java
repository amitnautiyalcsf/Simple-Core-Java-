package Java8Fearures;

//Abstract class--> define and declare method.
//Interface --> only declare method but upto version --> 1.7.
//in java 1.8 we can define methods in Interface.

//@FunctionalInterface  // it doesn't give us any error the reason is functional interface can have only one abstract method , so we can have any no of default methods 

interface Demo
{
	static int i =10;
	int j =20;
	public void show();
	default void disp()
	{
		System.out.println("It is a display method");
		System.out.println(i);
		System.out.println(j);
	}
	
	default void test()
	{
		
		System.out.println("This is a test method");
	}

	static void dance()
	{
		System.out.println("This is a staic method");
		System.out.println(i);
		System.out.println(j);
		
	}
}



	/*
	 * public void show()// that means the default method can also be overrided in
	 * the class itself {
	 * 
	 * System.out.println("in a new Show");
	 * 
	 * }
	 */


public class DefaultMethodinInterface 
{
	public static void main(String[] args) {
		
		Demo obj = new Demo() {
			
			public void show()
			{
				
				System.out.println("It is a show method");
			}
			
		};
		
		obj.show();
		obj.disp();
		obj.test();
		Demo.dance();
		
	}

}