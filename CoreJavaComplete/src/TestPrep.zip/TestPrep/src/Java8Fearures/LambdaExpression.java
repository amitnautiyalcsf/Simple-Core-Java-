package Java8Fearures;

@FunctionalInterface
interface A 
{

	public void disp();
}


abstract class AB{
	abstract void check();
}


public class LambdaExpression {

	public static void main(String[] args) {
		
		A obj = ()->{System.out.println("This is display method");};
		
		AB obj1 = new AB()
				{

					@Override
					void check() {
						// TODO Auto-generated method stub
						
					}
			
			
			
				};
				
		
		
		Thread t1 = new Thread(()-> {
			System.out.println("this is run method");
			
		},"Thread1");
		
		obj.disp();
		t1.start();
	System.out.println(t1.getName());
	}
	
}
