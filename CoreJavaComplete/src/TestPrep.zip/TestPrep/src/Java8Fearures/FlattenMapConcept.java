package Java8Fearures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

class Employee3
{

	private int id;
	private String name;
    private String designation;
	
    public Employee3(int id , String name, String designation) {
    	
    	this.id=id;
    	this.name=name;
    	this.designation= designation;
		
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", designation=" + designation + "]";
	}
    
    
    
    
}



public class FlattenMapConcept {
	
	public static void main(String[] args) {
		Employee3 obj = new Employee3(101, "Amit", "SoftwareEngineer");
		Employee3 obj1 = new Employee3(102,"Rohit", "SeniorSoftwareEngineer");
		Employee3 obj2 = new Employee3(103,"Manu", "AssociateITConsultant");
		
		Employee3 obj3 = new Employee3(104, "Ankit", "SoftwareEngineer");
		Employee3 obj4 = new Employee3(105,"Miffy", "SeniorSoftwareEngineer");
		Employee3 obj5 = new Employee3(106,"Vanu", "AssociateITConsultant");
	
		
		List<Employee3> al = Arrays.asList(obj,obj1,obj2);
		
		List<Employee3> al1 = Arrays.asList(obj3,obj4,obj5);
		
		
		List<List<Employee3>> al2 = Arrays.asList(al,al1);
		
		
		System.out.println(al2
				  .stream()
				  .flatMap(Collection::stream)
				  .collect(Collectors.toList()));		
		
	}

}
